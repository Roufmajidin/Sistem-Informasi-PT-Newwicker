<script>
    $(document).on(
        'click',
        '.btn-detail-draft',
        function () {
            let draftId =
                $(this).data('id');
            let requestNo =
                $(this).data('request');
            $('.draft-row')
                .removeClass(
                    'active-row'
                );
            $(this)
                .closest('tr')
                .addClass(
                    'active-row'
                );
            $('.draft-wrapper')
                .animate({
                    scrollLeft: $('.draft-detail')
                        .position()
                        .left
                }, 500);
            $.get(
                `/payment-request-saved/${draftId}/detail`,
                function (res) {
                    let requestDate = res.request_date ?? '';
                    let needDate = res.need_date ?? '';
                    let html = `
<div id="printArea">

                    <div style="background:white;
        padding:20px;
        font-family:Arial;
        font-size:11px;  ">
    {{-- HEADER --}}
    <table width="100%" style="   margin-bottom:10px;">
        <tr>
            {{-- LOGO --}}
            <td width="25%">
                                    <img src="{{ asset('/assets/images/NEWWICKER WHITE.png') }}" height="80">

            </td>
            {{-- TITLE --}}
            <td width="50%" align="center">
                <h2 style="margin:0;font-size:28px; ">
                    Purchase Request
                </h2>
            </td>
            {{-- NEED DATE --}}
            <td width="25%">
                <table width="100%" style="border-collapse:collapse;  ">
                    <tr>
                        <td style=" border:1px solid black; padding:4px; font-size:11px; ">     Need by Date :
                        </td>
                        <td style=" border:1px solid black;  padding:4px;font-size:11px;
                            ">
                            <input type="tet" id="need_date" value="${needDate}"
                                style="
                                    width:100%;
                                    border:none;
                                    outline:none;
                                    background:transparent;
                                    font-size:11px;
                                ">
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    {{-- INFO --}}
    <table width="100%" style="
            border-collapse:collapse;
            margin-bottom:10px;
        ">
        <tr>
            <td style="
                    border:1px solid black;
                    padding:4px;
                    width:180px;
                    font-weight:bold;
                ">
                Requisition Date :
            </td>
            <td style="
                    border:1px solid black;
                    padding:4px;
                ">
                <input type="text" id="request_date"value="${requestDate}" style="
                        width:100%;
                        border:none;
                        outline:none;
                        background:transparent;
                        font-size:11px;
                    ">
            </td>
            <td style="
                    border:1px solid black;
                    padding:4px;
                    width:180px;
                    font-weight:bold;
                ">
                Department :
            </td>
            <td style="
                    border:1px solid black;
                    padding:4px;
                ">
                <input type="text" value="Purchasing" style="
                        width:100%;
                        border:none;
                        outline:none;
                        background:transparent;
                        font-size:11px;
                    ">
            </td>
        </tr>
    </table>
    {{-- print BUTTON --}}
  <button
    id="btn-print"
    type="button"
    style="
        background:#111827;
        color:white;
        border:none;
        padding:8px 18px;
        border-radius:6px;
        font-size:12px;
        font-weight:bold;
        cursor:pointer;
    ">
    Print
</button>
                <div class="card">
                    <div class="card-header">
                        <h5>
                            ${res.request_no}
                        </h5>
                    </div>
                    <div class="card-body">
                        <table
                            class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>PO</th>
                                    <th>TGL</th>
                                    <th>Supplier</th>
                                    <th>Payment</th>
                                    <th>Description</th>
                                    <th>Keterangan</th>
                                    <th>Quantity</th>
                                    <th>sat</th>
                                    <th>Unit price</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
        `;
                 res.items.forEach(function (item, index) {
    html += `
        <tr style="font-size:11px;">
            <td>${index + 1}</td>
            <td>${item.no_po ?? ''}</td>
            <td>${item.tanggal ?? ''}</td>
            <td>${item.supplier ?? ''}</td>
            <td>Transfer</td>
            <td>
                <a href="/spk/edit/${item.spk_id}" target="_blank">
                    ${item.spk_no ?? ''}
                </a>
            </td>
            <td>${item.payment_note ?? ''}</td>
            <td></td>
            <td></td>
            <td></td>
            <td>
                Rp ${Number(item.payment_amount || 0).toLocaleString('id-ID')}
            </td>
            <td>Urgent</td>
        </tr>
    `;
});
                    html += `
                        </tbody>
                    </table>
                </div>
            </div>
        {{-- SIGNATURE SECTION --}}
          <div
    class="signature-section"
    style="
        margin-top:60px;
    ">
                        <table width="100%" style="
            text-align:center;
            font-size:11px;
        ">
                            <tr>
                                {{-- 1. AUTH USER --}}
                                <td width="12.5%">
                                    <div style="
                        font-weight:bold;
                        margin-bottom:5px;
                    ">
                                        Made By
                                    </div>
                                    <div style="height:70px;">
                                        <img src="
                        {{
                            $authUser->signature
                            ?? ''
                        }}
                        " style="
                            max-height:50px;
                        ">
                                    </div>
                                    <div style="
                        font-weight:bold;
                    ">
                                        {{ $authUser->name ?? '-' }}
                                    </div>
                                    <div style="
                        font-size:10px;
                    ">
                                        {{ $authUser->divisi->nama ?? '-' }}
                                    </div>
                                </td>
                                {{-- 2. KEPALA PURCHASING --}}
                                <td width="12.5%">
                                    <div style="
                        font-weight:bold;
                        margin-bottom:5px;
                    ">
                                        Checked By
                                    </div>
                                    <div style="height:70px;">
                                        <img src="
                        {{
                            $kepalaPurchasing->signature
                            ?? ''
                        }}
                        " style="
                            max-height:50px;
                        ">
                                    </div>
                                    <div style="
                        font-weight:bold;
                    ">
                                        {{ $kepalaPurchasing->nama ?? '-' }}
                                    </div>
                                    <div style="
                        font-size:10px;
                    ">
                                        {{ $kepalaPurchasing->divisi->nama ?? '-' }}
                                    </div>
                                </td>
                                {{-- 3. PROD MANAGER --}}
                                <td width="12.5%">
                                    <div style="
                        font-weight:bold;
                        margin-bottom:5px;
                    ">
                                        Checked By
                                    </div>
                                    <div style="height:70px;">
                                        <img src="
                        {{
                            $prodManager->signature
                            ?? ''
                        }}
                        " style="
                            max-height:50px;
                        ">
                                    </div>
                                    <div style="
                        font-weight:bold;
                    ">
                                        {{ $prodManager->nama ?? '-' }}
                                    </div>
                                    <div style="
                        font-size:10px;
                    ">
                                        {{ $prodManager->divisi->nama ?? '-' }}
                                    </div>
                                </td>
                                {{-- 4. CEO --}}
                                <td width="12.5%">
                                    <div style="
                        font-weight:bold;
                        margin-bottom:5px;
                    ">
                                        Approved By
                                    </div>
                                    <div style="height:70px;">
                                        <img src="
                        {{
                            $ceo->signature
                            ?? ''
                        }}
                        " style="
                            max-height:50px;
                        ">
                                    </div>
                                    <div style="
                        font-weight:bold;
                    ">
                                        {{ $ceo->nama ?? '-' }}
                                    </div>
                                    <div style="
                        font-size:10px;
                    ">
                                        {{ $ceo->divisi->nama ?? '-' }}
                                    </div>
                                </td>
                                {{-- 5. VP SALES --}}
                                <td width="12.5%">
                                    <div style="
                        font-weight:bold;
                        margin-bottom:5px;
                    ">
                                        Approved By
                                    </div>
                                    <div style="height:70px;">
                                        <img src="
                        {{
                            $vpSales->signature
                            ?? ''
                        }}
                        " style="
                            max-height:50px;
                        ">
                                    </div>
                                    <div style="
                        font-weight:bold;
                    ">
                                        {{ $vpSales->nama ?? '-' }}
                                    </div>
                                    <div style="
                        font-size:10px;
                    ">
                                        {{ $vpSales->divisi->nama ?? '-' }}
                                    </div>
                                </td>
                                {{-- 6. FINANCE --}}
                                <td width="12.5%">
                                    <div style="
                        font-weight:bold;
                        margin-bottom:5px;
                    ">
                                        Checked By Finance
                                    </div>
                                    <div style="height:70px;">
                                        <img src="
                        {{
                            $finance->signature
                            ?? ''
                        }}
                        " style="
                            max-height:50px;
                        ">
                                    </div>
                                    <div style="
                        font-weight:bold;
                    ">
                                        {{ $finance->nama ?? '-' }}
                                    </div>
                                    <div style="
                        font-size:10px;
                    ">
                                        {{ $finance->divisi->nama ?? '-' }}
                                    </div>
                                </td>
                                {{-- 7. HRD --}}
                                <td width="12.5%">
                                    <div style="
                        font-weight:bold;
                        margin-bottom:5px;
                    ">
                                        Approved By
                                    </div>
                                    <div style="height:70px;">
                                        <img src="
                        {{
                            $hrd->signature
                            ?? ''
                        }}
                        " style="
                            max-height:50px;
                        ">
                                    </div>
                                    <div style="
                        font-weight:bold;
                    ">
                                        {{ $hrd->nama ?? '-' }}
                                    </div>
                                    <div style="
                        font-size:10px;
                    ">
                                        {{ $hrd->divisi->nama ?? '-' }}
                                    </div>
                                </td>
                                {{-- 8. COO --}}
                                <td width="12.5%">
                                    <div style="
                        font-weight:bold;
                        margin-bottom:5px;
                    ">
                                        Approved By
                                    </div>
                                    <div style="height:70px;">
                                        <img src="
                        {{
                            $coo->signature
                            ?? ''
                        }}
                        " style="
                            max-height:50px;
                        ">
                                    </div>
                                    <div style="
                        font-weight:bold;
                    ">
                                        {{ $coo->nama ?? '-' }}
                                    </div>
                                    <div style="
                        font-size:10px;
                    ">
                                        {{ $coo->divisi->nama ?? '-' }}
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            </div>
        `;
                    $('#draftDetailArea')
                        .html(html);
                }
            );
        }
    );
</script>
<script>
     $(document).on(
    'click',
    '#btn-print',
    function () {

        let printContents =
            $('#printArea').html();

        let printWindow =
            window.open(
                '',
                '',
                'width=1200,height=900'
            );

        printWindow.document.write(`
            <html>
            <head>

                <title>
                    Purchase Request
                </title>

                <style>

                    @page{
                        size:A4 landscape;
                        margin:10mm;
                    }

                    body{
                        font-family:Arial;
                        font-size:11px;
                    }

                    table{
                        width:100%;
                        border-collapse:collapse;
                    }

                    th,
                    td{
                        border:1px solid #000;
                        padding:4px;
                        font-size:11px;
                    }

                    .signature-section{
                        page-break-inside:avoid;
                    }
 #btn-print
{
 display:none !important;}
                </style>

            </head>

            <body>

                ${printContents}

            </body>

            </html>
        `);

        printWindow.document.close();

        printWindow.focus();

        setTimeout(function(){
            printWindow.print();

            printWindow.close();

        },500);

    }
);
</script>
<style>

@media print {
 .card-title {

        display: none !important;

    }
    .nav,
    .nav-tabs,
    .nav-item,
    .spk-wrapper > .nav-tabs {

        display: none !important;

    }
    @page {
        size: A4 landscape;
        margin: 10mm;
    }

    body {
        margin:0;
    }

    #btn-print {
        display:none !important;
    }

    .no-print {
        display:none !important;
    }

    table {
        page-break-inside:auto;
    }

    tr {
        page-break-inside:avoid;
        page-break-after:auto;
    }

    .signature-section {
        page-break-inside:avoid;
    }
}

</style>
