@extends('master.master')

@section('content')

@include('pages.spk.monitoring-payment.style')

<div class="card shadow-sm mt-4">

    <div class="card-header bg-white">

        <div class="d-flex justify-content-between align-items-center">

            <h4 class="mb-0">

                {{-- <i class="fa fa-paint-brush text-primary"></i> --}}

                Finishing Monitoring

            </h4>

            <span class="badge bg-primary">

                Total :
                {{ $transaksiStok->count() }}

            </span>

        </div>

    </div>

    <div class="card-body">

        <div class="table-responsive p-4">

            <table class="table table-bordered table-hover table-striped align-middle">

                <thead class="table-dark">

                    <tr>

                        <th>No</th>

                <th id="sortTanggal" style="cursor:pointer;">
    TANGGAL OUT
    <i class="fa fa-sort ms-1"></i>
</th>

                        <th>PO</th>
                        <th>#SPK No</th>

                        <th>Sub</th>

                        <th>Kode</th>

                        <th>Nama Barang</th>

                        <th>Jenis</th>

                        <th>Qty</th>

                        <th>Satuan</th>

                        <th>Harga Barang</th>

                        <th>Total</th>

                    </tr>

                </thead>

                <tbody>

                @forelse($transaksiStok as $trx)

                    <tr>

                        <td>

                            {{ $loop->iteration }}

                        </td>

                        <td>

                            {{ \Carbon\Carbon::parse($trx->tanggal)->format('d M Y') }}

                        </td>

                        <td>

                            {{-- <span class="badge bg-info"> --}}

                                {{ $trx->po }}

                            {{-- </span> --}}

                        </td>
                        <td>
                            {{ $trx->spk_id ?? '-' }}

                        </td>

                        <td>

                            {{-- <span class="badge bg-success"> --}}

                                {{ strtoupper($trx->keterangan) }}

                            {{-- </span> --}}

                        </td>

                        <td>

                            {{ $trx->stok->kode_barang ?? '-' }}

                        </td>

                        <td>


                                {{ $trx->stok->nama_barang ?? '-' }}


                        </td>

                        <td>

                            {{ strtoupper($trx->stok->jenis ?? '-') }}

                        </td>

                        <td class="text-center">

                            {{ number_format($trx->qty,1) }}

                        </td>

                        <td>

                            {{ $trx->stok->satuan ?? '-' }}

                        </td>

                        <td class="text-end">

                            Rp

                            {{ number_format($trx->stok->harga ?? 0,0,',','.') }}

                        </td>

                        <td class="text-end">
 Rp. {{ number_format($trx->qty * $trx->stok->harga ?? 0,0,',','.') }}
                            {{-- @if($trx->harga_vivi)

                                Rp {{ number_format($trx->harga_vivi,0,',','.') }}

                            @else

                                <span class="text-muted">

                                    -

                                </span>

                            @endif --}}

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td colspan="11" class="text-center">

                            Tidak ada data.

                        </td>

                    </tr>

                @endforelse

                </tbody>

            </table>

        </div>

    </div>

</div>
<script>
  let tanggalAsc = false;

function parseTanggal(text) {

    const bulan = {
        Jan: 0,
        Feb: 1,
        Mar: 2,
        Apr: 3,
        May: 4,
        Jun: 5,
        Jul: 6,
        Aug: 7,
        Sep: 8,
        Oct: 9,
        Nov: 10,
        Dec: 11
    };

    text = text.trim();

    if (!text) return new Date(0);

    const p = text.split(/\s+/);

    return new Date(
        parseInt(p[2]),
        bulan[p[1]],
        parseInt(p[0])
    );
}

$("#sortTanggal").click(function () {

    tanggalAsc = !tanggalAsc;

    let tbody = $("table tbody");

    let rows = tbody.find("tr").get();

    rows.sort(function (a, b) {

        let aDate = parseTanggal($(a).find("td:eq(1)").text());
        let bDate = parseTanggal($(b).find("td:eq(1)").text());

        return tanggalAsc
            ? aDate - bDate
            : bDate - aDate;

    });

    $.each(rows, function (_, row) {
        tbody.append(row);
    });

    $(this).find("i")
        .removeClass("fa-sort fa-sort-up fa-sort-down")
        .addClass(tanggalAsc ? "fa-sort-up" : "fa-sort-down");

});
</script>
<style>
    .sortable{
    cursor:pointer;
    user-select:none;
}

.sortable:hover{
    background:#eef5ff;
}
</style>
@endsection