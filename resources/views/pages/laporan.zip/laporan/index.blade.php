@extends('master.master')
@section('title', 'Laporan Stok')
@section('content')
    <div class="padding">
        <div class="box">
            <div class="box-header d-flex justify-content-between">
                <h2>Laporan Stok</h2>
            </div>
            <div id="spkInfo"></div>
            <div class="box-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label>Jenis Barang</label>
                        <select id="filterJenis" class="form-control">
                            <option value="">Semua Jenis</option>
                            <option value="bahan baku">Bahan Baku</option>
                            <option value="bahan penolong">Bahan Penolong</option>
                            <option value="bahan penolong alat">Bahan Penolong Alat</option>
                        </select>

                    </div>
                    <div class="col-md-2">
    <label>-</label>
    <input
        type="text"
        id="searchBarang"
        class="form-control"
        placeholder="Cari nama barang...">
</div>
                    <div class="col-md-5 text-right">
                        <br>
                        <button type="button" class="btn btn-primary" id="addRow">
                            <i class="fa fa-plus"></i>
                            Tambah Baris
                        </button>
                        <button type="submit" form="formStok" class="btn btn-success">
                            <i class="fa fa-save"></i>
                            Simpan
                        </button>
                    </div>
                </div>
                <div id="wrapperStok" style="
    overflow-x:auto;
    overflow-y:hidden;
    width:100%;
">
                    <div id="canvasStok"
                        style="
        width:2200px;
        display:flex;
        align-items:flex-start;
    ">
                        <div id="masterPanel"
                            style="
               width:1600px;
            min-width:1300px;
            padding-right:20px;
        ">
                            <!-- tbl 1 -->
                            <form id="formStok" action="{{ route('laporan.update') }}" method="POST">
                                @csrf
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th width="50">No</th>
                                                <th>Kode Barang</th>
                                                <th>Nama Barang</th>
                                                <th style="min-width:180px;">Jenis</th>
                                                <th>Satuan</th>
                                                <th>Harga</th>
                                                <th>Total</th>
                                                <th>Stok in </th>
                                                <th>Stok out </th>
                                                <!-- <th>IN</th>
                                                <th>OUT</th> -->
                                                <th>Tanggal</th>
                                                <th width="80">Aksi</th>
                                                <th width="100">Detail</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tableBody">
                                            @forelse($stoks ?? [] as $key => $stok)
                                                <tr>
                                                    <td>{{ $key + 1 }}</td>
                                                    <td>
                                                        <input type="hidden" name="id[]" value="{{ $stok->id }}">
                                                        <input type="text" name="kode_barang[]"
                                                            value="{{ $stok->kode_barang }}" class="form-control">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="nama_barang[]"
                                                            value="{{ $stok->nama_barang }}" class="form-control">
                                                    </td>
                                                    <td>
                                                        <select name="jenis[]" class="form-control">
                                                            <option value="bahan baku"
                                                                {{ $stok->jenis == 'bahan baku' ? 'selected' : '' }}>
                                                                Bahan Baku
                                                            </option>
                                                            <option value="bahan penolong"
                                                                {{ $stok->jenis == 'bahan penolong' ? 'selected' : '' }}>
                                                                Bahan Penolong
                                                            </option>
                                                            <option value="bahan penolong alat"
                                                                {{ $stok->jenis == 'bahan penolong alat' ? 'selected' : '' }}>
                                                                Bahan Penolong Alat
                                                            </option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="satuan[]" value="{{ $stok->satuan }}"
                                                            class="form-control">
                                                    </td>
                                                    {{-- HARGA --}}
                                                    <td>
                                                        <input type="text" name="harga[]"
                                                            value="{{ !empty($stok->harga) ? number_format($stok->harga, 0, ',', '.') : '' }}"
                                                            class="form-control harga">
                                                    </td>
                                                    {{-- STOK AWAL --}}
                                                    <td>
                                                        {{ $stok->stok_akhir }}
                                                        <input type="hidden" name="stok_awal[]"
                                                            value="{{ $stok->stok_awal }}">
                                                    </td>
                                                    <td>
                                                        {{ $stok->total_in ?? 0 }}
                                                    </td>
                                                    <td>
                                                        {{ $stok->total_out ?? 0 }}
                                                    </td>
                                                    <td>
                                                        <input type="date" name="tanggal[]" value="{{ date('Y-m-d') }}"
                                                            class="form-control">
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-danger btn-sm remove-row">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-info btn-sm btn-detail"
                                                            data-id="{{ $stok->id }}">
                                                            Detail
                                                        </button>
                                                    </td>
                                                </tr>
                                            @empty
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                        <!-- tbl2 -->
                        <!-- TABEL DETAIL -->
                        <!-- DETAIL -->
                        <div id="detailPanel"
                            style="
            width:1200px;
            min-width:1000px;
            display:none;
        ">
                            <div class="alert alert-info">
                                Klik salah satu barang untuk melihat transaksi.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#addRow').click(function() {
                let rowCount = $('#tableBody tr').length + 1;
                let row = `
<tr>
    <td>${rowCount}</td>
    <td>
        <input type="hidden" name="id[]" value="">
        <input type="text" name="kode_barang[]" class="form-control">
    </td>
    <td>
        <input type="text" name="nama_barang[]" class="form-control">
    </td>
    <td>
        <select name="jenis[]" class="form-control">
            <option value="bahan baku">Bahan Baku</option>
            <option value="bahan penolong">Bahan Penolong</option>
            <option value="bahan penolong alat">Bahan Penolong Alat</option>
        </select>
    </td>
    <td>
        <input type="text" name="satuan[]" class="form-control">
    </td>
    <td>
        <input type="text" name="harga[]" class="form-control harga">
    </td>
    <td>
    <input type="number"
        step="0.001"
        name="stok_awal[]"
        class="form-control"
        value="0">
</td>
    <td>
        0
    </td>
    <td>
        0
    </td>
    <td>
        <input type="date"
            name="tanggal[]"
            value="{{ date('Y-m-d') }}"
            class="form-control">
    </td>
    <td>
        <button type="button"
            class="btn btn-danger btn-sm remove-row">
            <i class="fa fa-trash"></i>
        </button>
    </td>
    <td></td>
</tr>
`;
                $('#tableBody').append(row);
            });
            $(document).on('click', '.remove-row', function() {
                $(this).closest('tr').remove();
            });
            $('#filterJenis').change(function() {
                let jenis = $(this).val();
                $('#tableBody tr').each(function() {
                    let rowJenis = $(this).find('select[name="jenis[]"]').val();
                    if (jenis == '' || rowJenis == jenis) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            });
        });
    </script>
    <script>
        $(document).on('keyup change', '.stok-awal', function() {
            let row = $(this).closest('tr');
            row.find('.total-stok').text($(this).val() || 0);
        });
        $(document).on('keyup', '.harga', function() {
            let value = $(this).val().replace(/\D/g, '');
            $(this).val(
                new Intl.NumberFormat('id-ID').format(value)
            );
        });
    </script>
    <script>
        $(document).on('click', '.btn-detail', function() {
            let id = $(this).data('id');
            $.get('/laporan/' + id + '/detail', function(res) {
                let html = '';
                html += `
        <input type="hidden" id="spk_id" value="">
        <h4>${res.stok.nama_barang}</h4>
        <div class="card mb-3" margin-right:20px;">
            <div class="card-body">
                <input type="hidden"
                    id="stok_id"
                    value="${res.stok.id}">
                <div class="row">
                    <div class="col-md-2">
                        <label>Tanggal</label>
                        <input type="date"
                            id="tanggal"
                            class="form-control"
                            value="{{ date('Y-m-d') }}">
                    </div>
                    <div class="col-md-2">
                        <label>IN</label>
                        <input type="number"
                            step="0.001"
                            id="qty_in"
                            class="form-control">
                    </div>
                    <div class="col-md-2">
                        <label>OUT</label>
                        <input type="number"
                            step="0.001"
                            id="qty_out"
                            class="form-control">
                    </div>
                    <div class="col-md-5">
                       <div class="col-md-6">
                            <label>PO/SPK</label>
                            <input type="text"
                                id="po"
                                autocomplete="off"
                                class="form-control">
                            <div id="spkSuggestion"></div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label>Keterangan</label>
                        <input type="text"
                            id="keterangan"
                            class="form-control">
                    </div>
                    <div class="col-md-1">
                        <label>&nbsp;</label>
                        <button
                            type="button"
                            class="btn btn-success btn-block"
                            id="btnTambahTransaksi">
                            Save
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>IN</th>
                    <th>OUT</th>
                    <th>PO</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
        `;
                res.transaksi.forEach(function(item) {
                    html += `
                <tr>
                    <td>${item.tanggal}</td>
                    <td>
                        ${item.tipe == 'in'
                            ? item.qty
                            : ''}
                    </td>
                    <td>
                        ${item.tipe == 'out'
                            ? item.qty
                            : ''}
                    </td>
                    <td>
                        ${item.po ?? ''}
                    </td>
                    <td>
                        ${item.keterangan ?? ''}
                    </td>
                </tr>
            `;
                });
                html += `
            </tbody>
        </table>
        `;
                $('#detailPanel').html(html);
                $('#detailPanel').show();
                $('#wrapperStok').animate({
                    scrollLeft: $('#detailPanel')[0].offsetLeft
                }, 500);
            });
        });
    </script>
    <script>
        $(document).on('keyup', '.nama-barang', function() {
            let input = $(this);
            let value = input.val();
            if (value.length < 2) {
                input.prev('.ghost-text').text('');
                return;
            }
            $.get('/stok/search', {
                q: value
            }, function(res) {
                if (res) {
                    input.prev('.ghost-text')
                        .text(res.nama_barang);
                } else {
                    input.prev('.ghost-text')
                        .text('');
                }
            });
        });
    </script>
    <!-- transasksi -->
    <script>
        $(document).on('click', '#btnTambahTransaksi', function() {
            console.log({
                stok_id: $('#stok_id').val(),
                spk_id: $('#spk_id').val(),
                po: $('#po').val()
            });
            $.ajax({
                url: '/laporan/transaksi/store',
                type: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    stok_id: $('#stok_id').val(),
                    tanggal: $('#tanggal').val(),
                    in: $('#qty_in').val(),
                    out: $('#qty_out').val(),
                    po: $('#po').val(),
                    spk_id: $('#spk_id').val(),
                    keterangan: $('#keterangan').val()
                },
                success: function() {
                    $('.btn-detail[data-id="' + $('#stok_id').val() + '"]').click();
                }
            });
        });
    </script>
    <script>
        $(document).on('keyup', '#po', function() {
            let q = $(this).val();
            if (q.length < 2) {
                $('#spkSuggestion').html('');
                return;
            }
            $.get('/spk/search-spk', {
                q: q
            }, function(res) {
                // alert('masuk');
                let html = '';
                res.forEach(function(item) {
                    html += `
            <div
                class="spk-item"
                data-id="${item.id}"
                data-spk='${JSON.stringify(item)}'>
                ${item.no_spk}
            </div>
        `;
                });
                $('#spkSuggestion').html(html);
            });
        });
        $(document).on('click', '.spk-item', function() {
            let data = $(this).data('spk');
            $('#spk_id').val(data.id);
            $('#po').val(data.no_spk);
            console.log('SPK ID = ', data.id);
            let itemRows = '';
            data.items.forEach(function(item) {
                itemRows += `
            <tr>
                <td>${item.kode}</td>
                <td>${item.nama}</td>
                <td>${item.qty}</td>
            </tr>
        `;
            });
            $('#spkInfo').html(`
        <div class="alert alert-success">
            <h4>${data.no_spk}</h4>
            Supplier :
            ${data.supplier}
            <table class="table table-bordered mt-2">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Qty</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemRows}
                </tbody>
            </table>
        </div>
    `);
        });

        $('#searchBarang').on('keyup', function () {

    let keyword = $(this)
        .val()
        .toLowerCase();

    $('#tableBody tr').each(function () {

        let namaBarang = $(this)
            .find('input[name="nama_barang[]"]')
            .val()
            ?.toLowerCase() || '';

        if (
            namaBarang.indexOf(keyword) > -1
        ) {
            $(this).show();
        } else {
            $(this).hide();
        }

    });

});
function filterData()
{
    let keyword = $('#searchBarang')
        .val()
        .toLowerCase();

    let jenis = $('#filterJenis')
        .val()
        .toLowerCase();

    $('#tableBody tr').each(function () {

        let namaBarang = $(this)
            .find('input[name="nama_barang[]"]')
            .val()
            ?.toLowerCase() || '';

        let rowJenis = $(this)
            .find('select[name="jenis[]"]')
            .val()
            ?.toLowerCase() || '';

        let matchNama =
            keyword === '' ||
            namaBarang.includes(keyword);

        let matchJenis =
            jenis === '' ||
            rowJenis === jenis;

        $(this).toggle(
            matchNama && matchJenis
        );

    });
}

$('#searchBarang').on('keyup', filterData);

$('#filterJenis').on('change', filterData);
    </script>
    @include('pages.laporan.style')
@endsection
