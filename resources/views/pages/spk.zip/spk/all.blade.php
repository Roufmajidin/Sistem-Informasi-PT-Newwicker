@extends('master.master')
@section('title', "All SPK")
@section('content')

<div class="padding">
    <div class="box">
        <div class="box-header">
            <h2>All Spk</h2>
            <small></small>
            <div class="row" id="default-table">
                <div class="col-sm-12">
                    <div class="box">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width: 20px;">No</th>
                                        <th>Buyer Name</th>
                                        <th>Po</th>
                                        <th>Details</th>
                                    </tr>
                                </thead>
                                <tbody id="po-table-body">
                                    <tr>
                                        <td colspan="4" class="text-center text-muted">
                                            Loading...
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="box" id="spkDetailBox" style="display:none">
                            <div class="box-header">
                                <h3>Detail SPK</h3>
                                <small id="detailPoTitle"></small>
                            </div>

                            <div class="box-body">
                                <table class="table table-sm table-bordered">
                                    <!-- <thead>
                                        <tr>
                                            <th>No. SPK</th>
                                            <th>kategori</th>
                                            <th>act</th>
                                        </tr>
                                    </thead> -->
                                    <tbody id="spk-detail-body"></tbody>
                                </table>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endsection
        @push('scripts')
        <!-- jQuery (WAJIB PERTAMA) -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js"></script>

        <script>
            console.log(window.history.length);
            // ===============================
            // GLOBAL VARIABLE (WAJIB DI LUAR)
            // ===============================
            let cacheData = [];

            // ===============================
            // DOWNLOAD SPK
            // ===============================
            $(document).on('click', '.btn-download-spk', function() {
                const spkId = $(this).data('id');
                window.open(`/spk/export/${spkId}`, '_blank');
            });

            // ===============================
            // LOAD DATA PO
            // ===============================
            function loadSpkTable() {
                $.get("{{ route('spk.all') }}", function(res) {

                    cacheData = res;

                    let html = '';
                    let no = 1;

                    res.forEach((po, index) => {

                        let poId = po.data_po?.id;
                        let poNo = po.data_po?.no_po ?? '-';
                        let buyerName = po.data_po?.company ?? '-';
                        // count spk
                        let spkIds = new Set();

                        (po.data_po?.items || []).forEach(item => {
                            let summary = item.summary || {};

                            Object.values(summary).forEach(suppliers => {
                                Object.values(suppliers).forEach(supplier => {
                                    (supplier.spks || []).forEach(spk => {
                                        spkIds.add(spk.spk_id);
                                    });
                                });
                            });
                        });

                        let spkCount = spkIds.size;
                        html += `
                    <tr>
                        <td>${no++}</td>
                        <td>${buyerName}</td>
                        <td>${poNo}</td>
                      <td>
    <button
        class="btn btn-sm btn-primary btn-view-spk"
        data-index="${index}">
        View SPK (${spkCount})
    </button>
    <a href="/spk/${poId}"
       class="btn btn-sm btn-info">
        Buat SPK
    </a>
</td>
                    </tr>

                    <!-- DETAIL ROW -->
                    <tr id="detail-${poId}" class="detail-row" style="display:none;">
                        <td colspan="5">
                            <div class="detail-content"></div>
                        </td>
                    </tr>
                `;
                    });

                    $('#po-table-body').html(html);
                });
            }

            // ===============================
            // CLICK VIEW SPK (EXPAND TABLE)
            // ===============================
         $(document).on('click', '.btn-view-spk', function() {

    let index =
        $(this).data('index');

    let po =
        cacheData[index];

    let poId =
        po.data_po.id;

    let items =
        po.data_po.items || [];

    /*
    |--------------------------------------------------------------------------
    | CATEGORY
    |--------------------------------------------------------------------------
    */

    let categories = {

        rangka    : 'rangka',
        anyam     : 'anyam',
        unfinish  : 'unfinish',
        final     : 'final',
        decor     : 'decor',

        /*
        |--------------------------------------------------------------------------
        | ALIAS
        |--------------------------------------------------------------------------
        */

        // packaging : 'box',
        box       : 'box',

    };

    /*
    |--------------------------------------------------------------------------
    | CATEGORY COUNT
    |--------------------------------------------------------------------------
    */

    let totalCategory =
        Object.keys(categories).length;

    /*
    |--------------------------------------------------------------------------
    | TABLE HEADER
    |--------------------------------------------------------------------------
    */

    let html = `

        <table class="table table-sm table-bordered">

            <thead>

                <tr>

                    <th rowspan="2">
                        No
                    </th>

                    <th rowspan="2">
                        Article
                    </th>

                    <th rowspan="2">
                        Description
                    </th>

                    <th rowspan="2">
                        Qty
                    </th>

                    <th rowspan="2">
                        CBM
                    </th>

                    <th colspan="${totalCategory}">
                        SPK
                    </th>

                    <th rowspan="2">
                        Act
                    </th>

                </tr>

                <tr>

                    ${Object.keys(categories).map(cat => `

                        <th>

                            ${cat.toUpperCase()}

                        </th>

                    `).join('')}

                </tr>

            </thead>

            <tbody>

    `;

    /*
    |--------------------------------------------------------------------------
    | LOOP ITEM
    |--------------------------------------------------------------------------
    */

    items.forEach((item, i) => {

        let d =
            item.detail || {};

        let summary =
            item.summary || {};

        /*
        |--------------------------------------------------------------------------
        | CREATE EMPTY MAP
        |--------------------------------------------------------------------------
        */

        let map = {};

        Object.keys(categories).forEach(cat => {

            map[cat] = [];

        });

        /*
        |--------------------------------------------------------------------------
        | LOOP SUMMARY
        |--------------------------------------------------------------------------
        */

        Object.keys(summary).forEach(kategori => {

            Object.keys(summary[kategori]).forEach(supplier => {

                let data =
                    summary[kategori][supplier];

                (data.spks || []).forEach(spk => {

                    let tgl =
                        spk.tgl_selesai || '';

                    let deadline =
                        getDeadlineLabel(tgl);

                    /*
                    |--------------------------------------------------------------------------
                    | CONTENT
                    |--------------------------------------------------------------------------
                    */

                    let content = `

                        <div class="spk-card"
                             data-id="${spk.spk_id}"
                             data-no="${spk.no_spk}">

                            <b>
                                ${supplier}
                            </b>

                            (${spk.qty})

                            <br>

                            <small>

                                ${spk.no_spk}

                            </small>

                            <br>

                            <small>

                                ${deadline}

                            </small>

                            <br>

                            <div class="spk-btn-group">

                                <button
                                    class="btn btn-xs btn-success btn-download-spk"
                                    data-id="${spk.spk_id}">

                                    Download

                                </button>

                                <button
                                    class="btn btn-xs btn-warning btn-edit-spk"
                                    data-id="${spk.spk_id}">

                                    Edit

                                </button>

                            </div>

                            <div class="hold-progress"></div>

                        </div>

                    `;

                    /*
                    |--------------------------------------------------------------------------
                    | NORMALIZE CATEGORY
                    |--------------------------------------------------------------------------
                    */

                    let key =
                        kategori.toLowerCase();

                    /*
                    |--------------------------------------------------------------------------
                    | FIX DECOR
                    |--------------------------------------------------------------------------
                    */

                    if (key === 'décor') {

                        key = 'decor';

                    }

                    /*
                    |--------------------------------------------------------------------------
                    | ALIAS
                    |--------------------------------------------------------------------------
                    */

                    if (categories[key]) {

                        key =
                            categories[key];

                    }

                    /*
                    |--------------------------------------------------------------------------
                    | PUSH
                    |--------------------------------------------------------------------------
                    */

                    if (map[key]) {

                        map[key]
                            .push(content);

                    }

                });

            });

        });

        /*
        |--------------------------------------------------------------------------
        | MAX ROW
        |--------------------------------------------------------------------------
        */

        let lengths =
            Object.keys(map).map(cat => {

                return map[cat].length;

            });

        let maxRow =
            Math.max(...lengths, 1);

        /*
        |--------------------------------------------------------------------------
        | ROW TABLE
        |--------------------------------------------------------------------------
        */

        for (let r = 0; r < maxRow; r++) {

            html += `<tr>`;

            /*
            |--------------------------------------------------------------------------
            | FIRST ROW
            |--------------------------------------------------------------------------
            */

            if (r === 0) {

                html += `

                    <td rowspan="${maxRow}">

                        ${i + 1}

                    </td>

                   <td rowspan="${maxRow}"
    style="
        text-align:center;
        width:120px;
        min-width:120px;
        max-width:120px;
        vertical-align:top;
    ">

                       <div class="article-box">

    ${
        d.images && d.images.length
        ? `
            <img
                src="${d.images[0]}"
                class="article-image">
        `
        : d.photo
        ? `
            <img
                src="${d.photo}"
                class="article-image">
        `
        : `
            <div class="article-no-image">

                No Image

            </div>
        `
    }

    <div class="article-code">

        ${d.article_nr_ ?? '-'}

    </div>

</div>
                    </td>

                    <td rowspan="${maxRow}">

                        ${d.description ?? '-'}

                    </td>

                    <td rowspan="${maxRow}">

                        ${d.qty ?? 0}

                    </td>

                    <td rowspan="${maxRow}">

                        ${parseFloat(d.total_cbm ?? 0).toFixed(3)}

                    </td>

                `;

            }

            /*
            |--------------------------------------------------------------------------
            | CATEGORY COLUMN
            |--------------------------------------------------------------------------
            */

            Object.keys(categories).forEach(cat => {

                html += `

                    <td>

                        ${map[cat][r] || ''}

                    </td>

                `;

            });

            /*
            |--------------------------------------------------------------------------
            | ACTION
            |--------------------------------------------------------------------------
            */

            if (r === 0) {

                html += `

                    <td rowspan="${maxRow}">

                        <button
                            class="btn btn-sm btn-primary">

                            Action

                        </button>

                    </td>

                `;

            }

            html += `</tr>`;

        }

    });

    html += `

            </tbody>

        </table>

    `;

    /*
    |--------------------------------------------------------------------------
    | SHOW DETAIL
    |--------------------------------------------------------------------------
    */

    $('#spkDetailBox')
        .show();

    $('#detailPoTitle').html(`

        <b>

            ${po.data_po.no_po}

        </b>

        •

        ${po.data_po.company}

    `);

    $('#spk-detail-body').html(`

        <tr>

            <td colspan="3"
                style="padding:0;border:none">

                ${html}

            </td>

        </tr>

    `);

    /*
    |--------------------------------------------------------------------------
    | SCROLL
    |--------------------------------------------------------------------------
    */

    $('html, body').animate({

        scrollTop:
            $('#spkDetailBox').offset().top - 20

    }, 400);

});

            // ===============================
            // EDIT SPK
            // ===============================
            $(document).on('click', '.btn-edit-spk', function() {
                let spkId = $(this).data('id');
                window.location.href = `/spk/edit/${spkId}`;
            });

            $(document).on('click', '.spk-link', function() {
                let spkId = $(this).data('spk-id');
                window.location.href = `/spk/edit/${spkId}`;
            });

            // ===============================
            // INIT
            // ===============================

            $(document).ready(function() {
                loadSpkTable();
            });
            // load ddline spk
            function getDeadlineLabel(dateStr) {

                if (!dateStr) return '-';

                /*
                |--------------------------------------------------------------------------
                | FORMAT DD/MM/YYYY
                |--------------------------------------------------------------------------
                */

                let parts =
                    dateStr.split('/');

                let date = new Date(

                    parts[2],

                    parts[1] - 1,

                    parts[0]
                );

                let today =
                    new Date();

                /*
                |--------------------------------------------------------------------------
                | RESET HOUR
                |--------------------------------------------------------------------------
                */

                today.setHours(
                    0, 0, 0, 0
                );

                date.setHours(
                    0, 0, 0, 0
                );

                /*
                |--------------------------------------------------------------------------
                | DIFFERENCE
                |--------------------------------------------------------------------------
                */

                let diff = Math.ceil(

                    (date - today)

                    /

                    (1000 * 60 * 60 * 24)
                );

                /*
                |--------------------------------------------------------------------------
                | TODAY
                |--------------------------------------------------------------------------
                */

                if (diff === 0) {

                    return `

            <span style="
                color:green;
                font-weight:600;
            ">

                ✅ Hari ini

            </span>
        `;
                }

                /*
                |--------------------------------------------------------------------------
                | LATE
                |--------------------------------------------------------------------------
                */

                if (diff < 0) {

                    return `

            <span style="
                color:red;
                font-weight:600;
            ">

                ⚠️ Telat
                ${Math.abs(diff)} hari

            </span>
        `;
                }

                /*
                |--------------------------------------------------------------------------
                | WARNING <= 7 HARI
                |--------------------------------------------------------------------------
                */

                if (diff <= 7) {

                    return `

            <span style="
                color:red;
                font-weight:600;
            ">

                ⏳ ${diff} hari lagi

            </span>
        `;
                }

                /*
                |--------------------------------------------------------------------------
                | NORMAL
                |--------------------------------------------------------------------------
                */

                return `

        <span style="
            color:#6b7280;
        ">

            ⏳ ${diff} hari lagi

        </span>
    `;
            }
            // delete
            let holdTimer = null;

let holdInterval = null;

$(document).on('mousedown touchstart', '.spk-card', function(e) {

    /*
    |--------------------------------------------------------------------------
    | JANGAN TRIGGER SAAT KLIK BUTTON
    |--------------------------------------------------------------------------
    */

    if (
        $(e.target).closest('button').length
    ) {
        return;
    }

    let card =
        $(this);

    let spkId =
        card.data('id');

    let spkNo =
        card.data('no');

    let progress =
        card.find('.hold-progress');

    let width = 0;

    /*
    |--------------------------------------------------------------------------
    | RESET
    |--------------------------------------------------------------------------
    */

    progress.css({

        width: '0%',

        opacity: 1

    });

    /*
    |--------------------------------------------------------------------------
    | ANIMATION
    |--------------------------------------------------------------------------
    */

    holdInterval = setInterval(function() {

        width += 2;

        progress.css(
            'width',
            width + '%'
        );

    }, 100);

    /*
    |--------------------------------------------------------------------------
    | HOLD 5 DETIK
    |--------------------------------------------------------------------------
    */

    holdTimer = setTimeout(function() {

        clearInterval(
            holdInterval
        );

        progress.css(
            'opacity',
            0
        );

        Swal.fire({

            title: 'Yakin hapus SPK?',
            html: `
                SPK :
                <br>
                <b>${spkNo}</b>
            `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'Ya Delete',
            cancelButtonText: 'Cancel'

        }).then((result) => {

            if (result.isConfirmed) {

                $.ajax({

                    url: `/spk/delete/${spkId}`,

                    type: 'DELETE',

                    data: {
                        _token:
                        $('meta[name="csrf-token"]').attr('content')
                    },

                    success: function(res) {

                        Swal.fire({

                            icon: 'success',
                            title: 'Deleted',
                            text: res.message

                        });

                        loadSpkTable();

                        $('#spkDetailBox')
                            .hide();

                    },

                    error: function() {

                        Swal.fire({

                            icon: 'error',
                            title: 'Oops',
                            text: 'Gagal delete SPK'

                        });

                    }

                });

            }

        });

    }, 5000);

});

/*
|--------------------------------------------------------------------------
| CANCEL HOLD
|--------------------------------------------------------------------------
*/

$(document).on(
    'mouseup mouseleave touchend',
    '.spk-card',
    function() {

        clearTimeout(
            holdTimer
        );

        clearInterval(
            holdInterval
        );

        $(this)
            .find('.hold-progress')
            .css({

                width: '0%',

                opacity: 0

            });

    }
);
        </script>
        <style>
            .spk-card{

    overflow:hidden;

}
.article-box{

    display:flex;

    flex-direction:column;

    align-items:center;

    justify-content:flex-start;

    gap:6px;

    width:100px;

    margin:auto;

}

.article-image{

    width:70px;

    height:70px;

    object-fit:cover;

    border-radius:6px;

    border:1px solid #ddd;

    background:#fff;

    display:block;

}

/*
|--------------------------------------------------------------------------
| NO IMAGE
|--------------------------------------------------------------------------
*/

.article-no-image{

    width:70px;

    height:70px;

    border-radius:6px;

    border:1px dashed #ccc;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:10px;

    color:#999;

    background:#fafafa;

}

/*
|--------------------------------------------------------------------------
| ARTICLE CODE
|--------------------------------------------------------------------------
*/

.article-code{

    font-size:11px;

    font-weight:600;

    text-align:center;

    word-break:break-word;

    line-height:1.3;

}
.hold-progress{

    position:absolute;

    left:0;

    bottom:0;

    height:4px;

    width:0;

    background:#dc3545;

    opacity:0;

    transition:opacity .2s;
}
            .selected-spk {
                background-color: #ffeeba !important;
                border-left: 5px solid #f39c12;
                font-weight: 600;
            }

            .spk-detail-row {
                background: #f9f9f9;
            }

            /* BARANG */
            .barang-row td {
                padding: 12px 10px;
                background: #f9fafb;
                border-top: 2px solid #dee2e6;
            }

            .barang-title {
                font-weight: 600;
            }

            .barang-desc {
                font-size: 12px;
                color: #666;
            }

            .barang-qty {
                font-size: 11px;
                color: #999;
            }

            /* KATEGORI */
            .kategori-row td {
                padding: 6px 10px;
                font-style: italic;
                color: #555;
                background: #f1f3f5;
            }

            /* SPK */
            .spk-row td {
                padding: 6px 10px;
                font-size: 13px;
            }

            /* TABLE UMUM */
            table td {
                vertical-align: top;
            }
            #spkDetailBox{

    position: sticky;

    top: 10px;

    z-index: 20;

    background: white;

    border-radius: 10px;

    box-shadow: 0 10px 30px rgba(0,0,0,.08);

}
        </style>
        @endpush
