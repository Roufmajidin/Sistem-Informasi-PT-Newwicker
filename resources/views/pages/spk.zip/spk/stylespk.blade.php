
<style>
    body{
        background-color: white;
    }
    .spk-table td,
    .spk-table th {
        vertical-align: middle;
        padding: 6px;

    }
.spk-table {

    /* border-collapse: collapse; 🔥 WAJIB */
    width: 100%;
}

.spk-table th,
.spk-table td {
           background-color: white;

    border: 1px solid #000;   /* 🔥 GARIS TABEL */
}
    .editable {
        background: #fff8dc;
        cursor: text;
    }

    .spk-wrapper {
        overflow-x: auto;
    }

    .image-box {
        min-height: 90px;
        border: 1px dashed #ccc;
        padding: 4px;
        display: flex;
        flex-wrap: wrap;

    }

    .preview-img {
        height: 70px;
        margin: 4px;
        border: 1px solid #3c3c3cff;
        border-radius: 4px;
    }

    .editable {
        min-height: 28px;
        border-bottom: 5px solid #999;
        padding: 4px;
        outline: none;
    }

    .editable:empty:before {
        content: attr(data-placeholder);
        color: #aaa;
    }

    .suggest-box {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: #fff;
        border: 1px solid #282828ff;
        z-index: 999;
        max-height: 160px;
        overflow-y: auto;
        display: none;
    }

    .suggest-item {
        padding: 6px 8px;
        cursor: pointer;
    }

    .suggest-item:hover {
        background: #f6e9c6;
    }

    .note-box img {
        height: 60px;
        margin: 3px;
           background-color: white;

    }

    .spk-textarea {
        width: 100%;
        /* border: none; */
        resize: none;
        font-size: 11px;
        background: #fff8dc;
        line-height: 1.5;
           background-color: white;

    }

    .spk-textarea:focus {
        outline: none;
        background: #eef6ff;
    }

    @media print {
          .spk-table th,
    .spk-table td {
        border: 1px solid #000 !important;
    }
        .editable {
            background: none;
        }

        input[type=file] {
            display: none;
        }
    }

    .material {
        max-width: 200px;
        width: 200px;

        white-space: normal;
        /* AUTO WRAP */
        word-wrap: break-word;
        /* word lama */
        word-break: break-word;
        /* kata panjang */

        line-height: 1.4;
        vertical-align: top;
    }
    #supplierSugges {
         position:absolute;
            top:100%;
            left:0;
            right:0;
            background:#fff;
            border:1px solid #ccc;
            z-index:999;
            display:none;
            max-height:150px;
            overflow:auto;
    }
    .spk-header th {
    background:  #2b3c70ff; /* merah */
    color: #fff;
}
.request-chip{
    display:flex;
    align-items:center;
    gap:6px;
    padding:6px 10px;
    border-radius:20px;
    background:#fff;
    border:1px solid #ddd;
    cursor:pointer;
    transition:.2s;
    font-size:12px;
    font-weight:600;
}

.request-chip:hover{
    background:#fee2e2;
    border-color:#ef4444;
}

.request-chip input{
    accent-color:#dc2626;
}
</style>
