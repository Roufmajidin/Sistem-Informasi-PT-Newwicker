@extends('master.master')
@section('title','SPK Editable')
@section('content')

@include('pages.spk.stylespk')
@php
$checkedTypes = $spk['checked_types'] ?? [];
@endphp
@php
$status = $spk['status'] ?? 'draft';
@endphp

<div class="box">
    <div class="box-header d-flex justify-content-between align-items-center">
        <h3>SPK PRODUKSI</h3>
        @if($spk['mode'] === 'edit')
        <span class="warning">EDIT MODE</span>
        @else
        <span class="success">CREATE MODE</span>
        @endif
        <div style="min-width:180px">
            <label style="font-size:12px; margin-bottom:2px;"><b>Jenis SPK</b></label>
            <select name="spk_type" id="spk_type" class="form-control form-control-sm">

    <option value="">-- Pilih --</option>

    @foreach($jenisSuppliers as $jenis)

        <option value="{{ strtolower($jenis->name) }}"
            {{ strtolower($spk['type'] ?? '') == strtolower($jenis->name) ? 'selected' : '' }}>

            {{ $jenis->name }}

        </option>

    @endforeach

</select>
<div style="margin-top:8px">
    <button
        type="button"
        class="btn btn-dark btn-sm w-100"
        id="btnRiwayatSpk">

        🕘 Riwayat SPK
    </button>
</div>
        </div>

    </div>
    <input type="hidden" id="spk_mode" value="{{ $spk['mode'] }}">

    <input type="hidden" id="spk_id" value="{{ $spk['id'] }}">

    <div class="box-body spk-wrapper">
        <table class="table table-bordered spk-table">

            {{-- HEADER --}}
            <!-- @include('pages.spk.header') -->
            <tr>
                <td colspan="6" style="border:none">
                    <img src="/images/newwicker-logo.png" height="60">
                </td>
                <td colspan="6" class="text-right" style="border:none; position:relative">
                    <div class="editable" id="itemSearch" contenteditable
                        style="border:1px solid #ccc; padding:6px">
                        Ketik article / nama item
                    </div>
                    <div id="itemSuggest" class="suggest-box"></div>
                </td>
            </tr>

            <tr>
                <td colspan="12"></td>
            </tr>

            {{-- INFO --}}
            <tr>
                <td><b>NO SPK</b></td>
                <td colspan="1" class="editable no-spk" contenteditable>{{ $spk['no_spk'] }}</td>
                <td colspan="3"></td>
                <td><b>NO PO</b></td>
                <td colspan="3" class="editable no-po" contenteditable>{{ $spk['no_po'] }}</td>
                <td> <button id="btnSaveSpk" class="btn btn-success btn-sm">
                        💾 Save SPK
                    </button>
                <div style="
    display:flex;
    gap:8px;
    align-items:center;
    margin-top:6px;
">


    @if($status != 'finished')



        <button
            class="btn btn-sm btn-dark btn-status-spk"
            data-status="closed">

            🔒 Close SPK

        </button>

    @endif

</div>

                </td>
            </tr>

            <tr>
                <td><b>Nama</b></td>
                <td colspan="4" style="position:relative">
                    <div contenteditable="true"
                        class="editable"
                        id="supplierInput">
                        {{ $spk['nama'] }}
                    </div>

                    <div id="supplierSuggest">
                    </div>
                </td>

                <td colspan="7"></td>
            </tr>

            <tr>
                <td><b>Tgl Terima</b></td>
                <td colspan="4" class="editable tgl-terima" contenteditable>{{ $spk['tgl_terima'] }}</td>
                <td colspan="7"></td>
            </tr>

            <tr>
                <td><b>Tgl Selesai</b></td>
                <td colspan="4" class="editable tgl-selesai" contenteditable>{{ $spk['tgl_selesai'] }}</td>
                <td colspan="7"></td>
            </tr>

            @include('pages.spk.partial2')

            {{-- ITEMS --}}

            @foreach($spk['items'] as $item)
            <tr class="spk-row" data-detail-id="{{ $item['detail_id'] }}">


                <td style="cursor:pointer" class="editable text-center kode-item delete-row" contenteditable>{{ $item['kode'] }}</td>

                {{-- GAMBAR --}}
                <td>
                    <div class="image-box "
                        contenteditable
                        onpaste="handlePaste(event, this)">
                        @foreach($item['images'] as $img)
                        <img src="{{ $img }}" class="preview-img">
                        @endforeach

                        <input type="file"
                            accept="image/*"
                            multiple
                            capture="environment"
                            onchange="uploadPreview(this)">
                </td>
                <input type="hidden" class="spk-row" data-detail-id="{{ $item['detail_id'] }}">

            <td class="editable nama"
    contenteditable>

    {{ $item['nama'] }}

</td>
{{-- CUSTOM COLUMN VALUE --}}
@foreach($item['custom_columns'] ?? [] as $custom)

<td class="editable custom-column"
    contenteditable
    data-custom="{{ $custom['key'] ?? '' }}">

    {{ $custom['value'] ?? '' }}

</td>

@endforeach
<td class="editable text-center p group-col"
    contenteditable>

    {{ $item['p'] }}

</td>

<td class="editable text-center l group-col"
    contenteditable>

    {{ $item['l'] }}

</td>

<td class="editable text-center t group-col"
    contenteditable>

    {{ $item['t'] }}

</td>
                @foreach($spk['additional_headers'] ?? [] as $header)

<td class="editable dynamic-field"
    contenteditable
    data-key="{{ $header['key'] }}">

    {{ $item['additional_fields'][$header['key']] ?? '' }}

</td>

@endforeach
                <td class="editable material" contenteditable>{{ $item['material'] }}</td>
                <td class="editable text-center pcs" contenteditable>{{ $item['pcs'] }}</td>
                <td class="editable text-center set" contenteditable>{{ $item['set'] }}</td>
                <td class="editable text-right harga" contenteditable>{{ $item['harga'] }}</td>
                <td class="text-right total">0</td>

                {{-- CATATAN --}}
                {{-- CATATAN --}}
                <td>
                    <div class="editable note-box"
                        contenteditable
                        onpaste="handlePaste(event, this)">

                        @foreach($item['catatan']['images'] ?? [] as $img)
                        <img src="{{ $img }}" class="preview-img">
                        @endforeach

                        {!! $item['catatan']['remark'] ?? '' !!}
                    </div>
                </td>

            </tr>

            @endforeach

            <tr id="spkItemAnchor"></tr>

            @include('pages.spk.partial1')
           <td colspan="3" style="vertical-align: top;margin-left:12px">

    <table class="table table-bordered"  style="font-size:12px; width:100%; min-width:520px;">

 <tr class="text-center">

    <th width="5%">
        Req
    </th>

    <th width="20%">
        Amount
    </th>

    <th width="20%">
        Date
    </th>

    <th width="20%">
        Note
    </th>

    <th width="35%">
        Keterangan
    </th>

</tr>

    <tbody id="paymentBody">

        @php
            $payments = $spk['payments'] ?? [];
        @endphp

        @if(count($payments))

            @foreach($payments as $pay)

            @php

$paymentId =
    $pay['payment_id']
    ?? 'pay_' . uniqid();

@endphp

<tr class="payment-row"
    data-payment-id="{{ $paymentId }}"
    data-pr-id="{{ $pay['pr_id'] ?? '' }}">
    <!-- CHECKBOX -->
    <td class="text-center">

        <input type="checkbox"
            class="payment-request-check"
            {{ ($pay['is_request'] ?? false) ? 'checked' : '' }}>

    </td>

    <!-- AMOUNT -->
    <td class="editable total-amount" contenteditable>
        {{ $pay['amount'] ?? '' }}
    </td>

    <!-- DATE -->
    <td class="editable date-isian" contenteditable>
        {{ $pay['date'] ?? '' }}
    </td>

    <!-- TYPE -->
    <td>

        <select class="form-control form-control-sm payment-type">

            <option value="">-- Pilih --</option>

            <option value="dp"
                {{ ($pay['note'] ?? '') == 'dp' ? 'selected' : '' }}>
                DP
            </option>

            <option value="pelunasan"
                {{ ($pay['note'] ?? '') == 'pelunasan' ? 'selected' : '' }}>
                Pelunasan
            </option>

            <option value="bahan"
                {{ ($pay['note'] ?? '') == 'bahan' ? 'selected' : '' }}>
                Bahan
            </option>

            <option value="kasbon"
                {{ ($pay['note'] ?? '') == 'kasbon' ? 'selected' : '' }}>
                Kasbon
            </option>

        </select>

    </td>

    <!-- KETERANGAN -->
    <td class="editable note-tambahan" contenteditable>
        {{ $pay['note_tambahan'] ?? '' }}
    </td>

</tr>

            @endforeach

        @else

          <tr class="payment-row"
    data-payment-id="pay_{{ uniqid() }}"
    data-pr-id="">

    <!-- CHECK -->
    <td class="text-center">

        <input type="checkbox"
            class="payment-request-check">

    </td>

    <!-- AMOUNT -->
    <td class="editable total-amount"
        contenteditable>
    </td>

    <!-- DATE -->
    <td class="editable date-isian"
        contenteditable>
    </td>

    <!-- TYPE -->
    <td>

        <select class="form-control form-control-sm payment-type">

            <option value="">
                -- Pilih --
            </option>

            <option value="dp">DP</option>
            <option value="pelunasan">Pelunasan</option>
            <option value="bahan">Bahan</option>
            <option value="kasbon">Kasbon</option>

        </select>

    </td>

    <!-- NOTE -->
    <td class="editable note-tambahan"
        contenteditable>
    </td>

</tr>

        @endif

    </tbody>

    <tfoot>

        <tr>
            <td colspan="4" class="text-center">

                <button type="button"
                    id="btnAddPayment"
                    class="btn btn-sm btn-primary">

                    + Tambah Baris

                </button>

            </td>
        </tr>

        <tr>
            <td colspan="4">

                <div id="paymentSummary"
                    style="
                        padding:10px;
                        font-size:13px;
                        line-height:1.8;
                    ">
                </div>

            </td>
        </tr>

    </tfoot>

</table>

</td>
        </table>

    </div>
</div>
<!-- MODAL RIWAYAT -->
<div class="modal fade" id="modalRiwayatSpk" tabindex="-1">

    <div class="modal-dialog modal-lg modal-dialog-scrollable">

        <div class="modal-content">

            <div class="modal-header bg-dark text-white">

                <h5 class="modal-title">
                    Riwayat SPK
                </h5>

                <button type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">
                </button>

            </div>

            <div class="modal-body"
                id="timelineContainer"
                style="
                    background:#ece5dd;
                    min-height:500px;
                    padding:20px;
                    overflow-y:auto;
                ">

            </div>

        </div>

    </div>

</div>
<!-- search -->
<!-- heler -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    function extractNoteData(noteBox) {
        let remark = '';
        let images = [];

        noteBox.childNodes.forEach(node => {
            if (node.nodeType === Node.TEXT_NODE) {
                remark += node.textContent.trim();
            }

            if (node.nodeType === Node.ELEMENT_NODE && node.tagName === 'IMG') {
                images.push(node.src);
            }
        });

        return {
            remark: remark,
            images: images
        };
    }
</script>

<!-- delete row -->
<script>
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('delete-row')) {

            const row = e.target.closest('tr');

            Swal.fire({
                title: 'Yakin?',
                text: 'Baris ini akan dihapus',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, hapus',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    row.remove();
                    renumberRows();

                    Swal.fire({
                        icon: 'success',
                        title: 'Terhapus',
                        text: 'Baris berhasil dihapus',
                        timer: 1200,
                        showConfirmButton: false
                    });
                }
            });
        }
    });

    function renumberRows() {
        document.querySelectorAll('.spk-row').forEach((row, index) => {
            const noCell = row.querySelector('.row-no');
            if (noCell) {
                noCell.innerText = index + 1;
            }
        });
    }
</script>
<!-- helper wraping text -->
<script>
    document.addEventListener('keydown', function(e) {

        if (!e.target.isContentEditable) return;

        // BOLEH ENTER di material & catatan
        if (e.target.classList.contains('material') ||
            e.target.classList.contains('note-box')) {
            return;
        }

        // BLOK ENTER di field lain
        if (e.key === 'Enter') {
            e.preventDefault();
        }
    });
</script>
<!-- hitung helper -->
<script>
    function getSatuan(row) {
        const pcs = parseFloat(row.querySelector('.pcs')?.innerText) || 0;
        const set = parseFloat(row.querySelector('.set')?.innerText) || 0;

        if (pcs > 0) return 'pcs';
        if (set > 0) return 'set';
        return '';
    }

    function getNumber(el) {
        if (!el) return 0;
        return parseFloat(el.innerText.replace(/[^0-9]/g, '')) || 0;
    }

    function format(num) {
        return new Intl.NumberFormat('id-ID').format(num);
    }

    /* =====================
       HITUNG TOTAL PER ROW
       ===================== */
    function hitungTotal(row) {
        const pcs = getNumber(row.querySelector('.pcs'));
        const set = getNumber(row.querySelector('.set'));
        const harga = getNumber(row.querySelector('.harga'));

        const qty = pcs > 0 ? pcs : set;
        const total = qty * harga;

        const totalCell = row.querySelector('.total');
        if (totalCell) {
            totalCell.innerText = format(total);
        }

        hitungGrandTotal();
    }

    /* =====================
       HITUNG TOTAL AMOUNT
       ===================== */
    function hitungGrandTotal() {
        let grandTotal = 0;

        document.querySelectorAll('.spk-table .total').forEach(td => {
            grandTotal += getNumber(td);
        });

      const amountCell = document.querySelector('.grand-total-display');

if (amountCell) {
    amountCell.innerText = format(grandTotal);
}
    }

    /* =====================
       EVENT LISTENER
       ===================== */
    document.addEventListener('keyup', function(e) {
        if (e.target.closest('.pcs, .set, .harga')) {
            const row = e.target.closest('tr');
            hitungTotal(row);
        }
    });

    document.addEventListener('paste', function(e) {
        if (e.target.closest('.pcs, .set, .harga')) {
            setTimeout(() => {
                const row = e.target.closest('tr');
                hitungTotal(row);
            }, 10);
        }
    });

    /* =====================
       HITUNG SAAT LOAD
       ===================== */
    document.querySelectorAll('.spk-table tr').forEach(row => {
        if (row.querySelector('.pcs') || row.querySelector('.set')) {
            hitungTotal(row);
        }
    });
</script>

<script>
    document.addEventListener('keydown', function(e) {
        if (e.target.isContentEditable && e.key === 'Enter') {
            e.preventDefault();
        }
    });
</script>
<script>
    const input = document.getElementById('supplierInput');
    const suggestBox = document.getElementById('supplierSuggest');
    let typingTimer;

    input.addEventListener('input', function() {
        const keyword = input.innerText.trim();

        clearTimeout(typingTimer);

        if (keyword.length < 2) {
            suggestBox.style.display = 'none';
            return;
        }

        typingTimer = setTimeout(() => {
            fetch(`/supplier/search?q=${encodeURIComponent(keyword)}`)
                .then(res => res.json())
                .then(data => {
                    suggestBox.innerHTML = '';

                    if (data.length === 0) {
                        suggestBox.style.display = 'none';
                        return;
                    }

                    data.forEach(item => {
                        const div = document.createElement('div');
                        div.className = 'suggest-item';
                        div.textContent = item.name;
                        div.onclick = () => {
                            input.innerText = item.name;
                            suggestBox.style.display = 'none';
                        };
                        suggestBox.appendChild(div);
                    });

                    suggestBox.style.display = 'block';
                });
        }, 300);
    });

    document.addEventListener('click', function(e) {
        if (!input.contains(e.target) && !suggestBox.contains(e.target)) {
            suggestBox.style.display = 'none';
        }
    });
</script>

<script>
    function handlePaste(e, container) {
        let items = (e.clipboardData || window.clipboardData).items;

        for (let i = 0; i < items.length; i++) {
            let item = items[i];

            if (item.type.indexOf("image") !== -1) {
                e.preventDefault();

                let blob = item.getAsFile();
                let reader = new FileReader();

                reader.onload = function(event) {
                    let img = document.createElement('img');
                    img.src = event.target.result;
                    img.className = 'preview-img';
                    container.appendChild(img);
                };

                reader.readAsDataURL(blob);
            }
        }
    }

    function uploadPreview(input) {
        let container = input.previousElementSibling;

        Array.from(input.files).forEach(file => {
            let reader = new FileReader();
            reader.onload = e => {
                let img = document.createElement('img');
                img.src = e.target.result;
                img.className = 'preview-img';
                container.appendChild(img);
            };
            reader.readAsDataURL(file);
        });

        input.value = '';
    }
</script>
<!-- save data -->
<script>
    document.getElementById('btnSaveSpk').addEventListener('click', function() {

        let items = [];
        let payments = [];
        document.querySelectorAll('.payment-row').forEach(row => {

      payments.push({
payment_id:
    row.dataset.paymentId,
    amount: (
        row.querySelector('.total-amount')?.innerText || ''
    ).replace(/\./g, ''),

    date:
        row.querySelector('.date-isian')?.innerText.trim() || '',

    note:
        row.querySelector('.payment-type')?.value || '',

    note_tambahan:
        row.querySelector('.note-tambahan')?.innerText.trim() || '',

    is_request:
        row.querySelector('.payment-request-check')?.checked || false

});
        });
        document.querySelectorAll('.spk-row').forEach(row => {
            const detailId = row.dataset.detailId;
            if (!detailId) return;

            let images = [];
            row.querySelectorAll('.image-box img').forEach(img => {
                images.push(img.src);
            });

            const noteBox = row.querySelector('.note-box');
            let customColumns = [];

            row.querySelectorAll('.custom-column')
            .forEach(col => {

                customColumns.push({

                    key:
                        col.dataset.custom,

                    value:
                        col.innerText.trim()

                });

            });
            items.push({
                detail_id: detailId,
                kode: row.querySelector('.kode-item')?.innerText.trim() || '',
                nama: row.querySelector('.nama')?.innerText.trim() || '',
                p: row.querySelector('.p')?.innerText.trim() || '',
                  custom_columns:
        customColumns,
                l: row.querySelector('.l')?.innerText.trim() || '',
                t: row.querySelector('.t')?.innerText.trim() || '',
                material: row.querySelector('.material')?.innerText.trim() || '',
                pcs: row.querySelector('.pcs')?.innerText.trim() || '',
                set: row.querySelector('.set')?.innerText.trim() || '',
                satuan: getSatuan(row),
                harga: row.querySelector('.harga')?.innerText.trim() || '',
                total: getNumber(row.querySelector('.total')),
                images: images,
                catatan: noteBox ? extractNoteData(noteBox) : {
                    remark: '',
                    images: []
                }
            });
        });

        const mode = document.getElementById('spk_mode')?.value;
        const spkId = document.getElementById('spk_id')?.value;
        const noSpkEl = document.querySelector('.no-spk');
        const noPoEl = document.querySelector('.no-po');

let customHeaders = [];

document.querySelectorAll(
    '.spk-dynamic-header'
)
.forEach((th,index) => {

    customHeaders.push({

        key:index + 1,

        label:th.innerText

    });

});

        const payload = {
            spk_id: mode === 'edit' ? spkId : null, // 🔥 KUNCI
            spk_type: document.getElementById('spk_type').value,
            custom_headers:
    customHeaders,
            no_spk: noSpkEl ? noSpkEl.innerText.trim() : '',
            no_po: noPoEl ? noPoEl.innerText.trim() : '',
            nama: document.getElementById('supplierInput')?.innerText || '',
            tgl_terima: document.querySelector('.tgl-terima')?.innerText || '',
            tgl_selesai: document.querySelector('.tgl-selesai')?.innerText || '',
            items: items,
            payments: payments
        };
        //     console.log('NO SPK:', payload.no_spk);
        // console.log('NO PO:', payload.no_po);

        // 🔥 URL DINAMIS
        let url = '';
        if (mode === 'edit') {
            url = "{{ url('/spk/update') }}/" + spkId;
        } else {
            url = "{{ url('/spk/create') }}/" + spkId; // spkId = PO ID
        }

        fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": "{{ csrf_token() }}"
                },
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(res => {
                if (res.success) {

                    Swal.fire({
                        icon: 'success',
                        title: 'SPK Berhasil',
                        html: `
                <div style="font-size:14px">
                    ${res.message}<br><br>
                    <b>No SPK:</b><br>
                    <span style="font-size:18px;color:#198754">
                        ${res.no_spk}
                    </span>
                </div>
            `,
                        confirmButtonText: 'OK'
                    });

                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: res.message || 'Gagal menyimpan SPK'
                    });
                }
            })
            .catch(err => {
                console.error(err);

                Swal.fire({
                    icon: 'error',
                    title: 'Error Server',
                    text: 'Terjadi kesalahan pada server'
                });
            });
    });
</script>


<!-- search and add row -->
<script>
    const itemInput = document.getElementById('itemSearch');
    const itemSuggest = document.getElementById('itemSuggest');
    let itemTimer;

    itemInput.addEventListener('input', function() {

        const keyword = itemInput.innerText.trim();

        clearTimeout(itemTimer);

        if (keyword.length < 2) {
            itemSuggest.style.display = 'none';
            return;
        }

        itemTimer = setTimeout(() => {

            fetch("{{ route('detailpo.search') }}?q=" + encodeURIComponent(keyword))

                .then(res => res.json())
                .then(data => {

                    itemSuggest.innerHTML = '';

                    if (!data.length) {
                        itemSuggest.style.display = 'none';
                        return;
                    }

                    data.forEach(item => {

                        const div = document.createElement('div');
                        div.className = 'suggest-item';

                        div.innerHTML = `
                    <b>${item.kode}</b><br>
                    <small>${item.nama}</small>
                `;

                        div.onclick = () => {
                            addItemRow(item);
                            itemInput.innerText = '';
                            itemSuggest.style.display = 'none';
                        };

                        itemSuggest.appendChild(div);
                    });

                    itemSuggest.style.display = 'block';
                });

        }, 300);
    });
</script>
<!-- add rows -->
<script>
    function addItemRow(item) {

        const exist = document.querySelector(
            `.spk-row[data-detail-id="${item.detail_id}"]`
        );

        if (exist) {
            alert('Item sudah ada');
            return;
        }

        // ===== BUILD IMAGE HTML =====
        let imagesHtml = '';

        if (item.images && item.images.length) {
            item.images.forEach(img => {
                imagesHtml += `<img src="${img}" class="preview-img">`;
            });
        }

        // fallback kalau backend cuma kirim photo
        if (!imagesHtml && item.photo) {
            imagesHtml = `<img src="${item.photo}" class="preview-img">`;
        }

        const tr = document.createElement('tr');
        tr.classList.add('spk-row');
        tr.dataset.detailId = item.detail_id;

        tr.innerHTML = `
        <td class="editable text-center kode-item delete-row" contenteditable>${item.kode}</td>

        <td>
            <div class="image-box" contenteditable onpaste="handlePaste(event,this)">
                ${imagesHtml}
            </div>

            <input type="file"
                accept="image/*"
                multiple
                capture="environment"
                onchange="uploadPreview(this)">
        </td>

        <td class="editable nama group-col"
    contenteditable>

    ${item.nama ?? ''}

</td>

<td class="editable text-center p group-col"
    contenteditable>

    ${item.p ?? ''}

</td>

<td class="editable text-center l group-col"
    contenteditable>

    ${item.l ?? ''}

</td>

<td class="editable text-center t group-col"
    contenteditable>

    ${item.t ?? ''}

</td>
        <td class="editable material" contenteditable>${item.material ?? ''}</td>
        <td class="editable text-center pcs" contenteditable>${item.qty ?? 0}</td>
        <td class="editable text-center set" contenteditable>0</td>
        <td class="editable text-right harga" contenteditable>0</td>
        <td class="text-right total">0</td>

        <td>
            <div class="editable note-box"
                contenteditable
                onpaste="handlePaste(event,this)">
            </div>
        </td>
    `;

        const anchor = document.getElementById('spkItemAnchor');

        if (anchor) {
            anchor.before(tr);
        } else {
            document.querySelector('.spk-table tbody').appendChild(tr);
        }

        hitungTotal(tr);
    }
</script>
<script>

document.getElementById('btnAddPayment')
.addEventListener('click', function() {

    let tr = document.createElement('tr');

    let paymentId =
        'pay_' + Date.now();

    tr.classList.add('payment-row');

    tr.setAttribute(
        'data-payment-id',
        paymentId
    );

    tr.innerHTML = `

        <td class="text-center">
            <input type="checkbox"
                class="payment-request-check">
        </td>

        <td class="editable total-amount"
            contenteditable>
        </td>

        <td class="editable date-isian"
            contenteditable>
        </td>

        <td>

            <select class="form-control
                form-control-sm payment-type">

                <option value="">
                    -- Pilih --
                </option>

                <option value="dp">
                    DP
                </option>
    <option value="bahan">
                    Bahan
                </option>
                <option value="kasbon">
                    Kasbon
                </option>

                <option value="pelunasan">
                    Pelunasan
                </option>

            </select>

        </td>

        <td class="editable note-tambahan"
            contenteditable>
        </td>
    `;

    document
        .getElementById('paymentBody')
        .appendChild(tr);
});
</script>
<script>
async function savePaymentRequestRow(row) {

    try {

        // =========================
        // VALIDASI ROW
        // =========================
        if (!row) {
            return;
        }

        // =========================
        // AMBIL DATA
        // =========================
        const amount =
            (
                row.querySelector('.total-amount')
                ?.innerText || ''
            )
            .replace(/\./g, '')
            .trim();

        const date =
            row.querySelector('.date-isian')
            ?.innerText
            .trim() || '';

        const note =
            row.querySelector('.payment-type')
            ?.value || '';

        const noteTambahan =
            row.querySelector('.note-tambahan')
            ?.innerText
            .trim() || '';

        const isRequest =
            row.querySelector('.payment-request-check')
            ?.checked || false;

        // =========================
        // VALIDASI
        // =========================
        if (!note) {

            Swal.fire({
                icon: 'warning',
                title: 'Jenis payment kosong',
                text: 'Pilih jenis payment terlebih dahulu'
            });

            row.querySelector('.payment-request-check').checked = false;

            return;
        }

        if (!amount || parseInt(amount) <= 0) {

            Swal.fire({
                icon: 'warning',
                title: 'Nominal kosong',
                text: 'Isi nominal payment terlebih dahulu'
            });

            row.querySelector('.payment-request-check').checked = false;

            return;
        }

        // =========================
        // FORMAT TANGGAL
        // 12/05/26 => 12/05/2026
        // =========================
        let finalDate = date;

        if (date) {

            const split = date.split('/');

            if (
                split.length === 3 &&
                split[2].length === 2
            ) {

                finalDate =
                    split[0] + '/' +
                    split[1] + '/20' +
                    split[2];
            }
        }

        // =========================
        // PAYLOAD
        // =========================
        const payload = {

            spk_id:
                document.getElementById('spk_id')
                ?.value,

            no_spk:
                document.querySelector('.no-spk')
                ?.innerText
                .trim(),

            payment: {
 payment_id:
        row.dataset.paymentId,
                amount: amount,

                date: finalDate,

                note: note,

                note_tambahan: noteTambahan,

                is_request: isRequest
            }
        };

        console.log('PAYLOAD:', payload);

        // =========================
        // LOADING
        // =========================
        row.style.opacity = '.6';
        row.style.pointerEvents = 'none';

        // =========================
        // FETCH
        // =========================
        const response = await fetch(
            '/payment-request/store',
            {
                method: 'POST',

                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN':
                        '{{ csrf_token() }}'
                },

                body: JSON.stringify(payload)
            }
        );

        // =========================
        // RESPONSE JSON
        // =========================
        let result = {};

        try {

            result = await response.json();

        } catch (e) {

            throw new Error(
                'Response server tidak valid'
            );
        }

        console.log('RESULT:', result);

        // =========================
        // HANDLE ERROR HTTP
        // =========================
        if (!response.ok) {

            throw new Error(
                result.message ||
                'Terjadi kesalahan server'
            );
        }

        // =========================
        // HANDLE FAILED
        // =========================
        if (!result.success) {

            throw new Error(
                result.message ||
                'Gagal membuat request'
            );
        }

        // =========================
        // SUCCESS
        // =========================
        Toast.fire({
            icon: 'success',
            title:
                isRequest
                ? 'Payment request dibuat'
                : 'Payment request dibatalkan'
        });

        // =========================
        // AUTO SAVE SPK
        // supaya JSON sync
        // =========================
        const saveBtn =
            document.getElementById('btnSaveSpk');

        if (saveBtn) {

            saveBtn.click();
        }

    } catch (err) {

        console.error(err);

        // rollback checkbox
        const checkbox =
            row.querySelector(
                '.payment-request-check'
            );

        if (checkbox) {

            checkbox.checked = !checkbox.checked;
        }

        Swal.fire({
            icon: 'error',
            title: 'Gagal',
            text:
                err.message ||
                'Terjadi kesalahan'
        });

    } finally {

        // =========================
        // ENABLE ROW
        // =========================
        row.style.opacity = '1';
        row.style.pointerEvents = 'auto';
    }
}
function parseNumber(value) {

    return parseInt(
        (value || '').toString().replace(/\./g, '')
    ) || 0;
}

function formatRupiah(value) {

    value = parseInt(
        value.toString().replace(/[^\d]/g, '')
    ) || 0;

    return new Intl.NumberFormat('id-ID').format(value);
}

function updatePaymentSummary() {

    // =========================
    // GRAND TOTAL SPK
    // =========================

    let grandTotal = 0;

    document.querySelectorAll('.total').forEach(td => {

        grandTotal += parseNumber(td.innerText);
    });

    // =========================
    // PAYMENT TOTAL
    // =========================

    let totalDp = 0;
    let totalBahan = 0;
    let totalPelunasan = 0;
let totalKasbon = 0;
    document.querySelectorAll('.payment-row').forEach(row => {

        let amount = parseNumber(
            row.querySelector('.total-amount')?.innerText
        );

        let type = row.querySelector('.payment-type')?.value;

        if (type === 'dp') {
            totalDp += amount;
        }

        if (type === 'bahan') {
            totalBahan += amount;
        }

        if (type === 'pelunasan') {
            totalPelunasan += amount;
        }
        if (type === 'kasbon') {
    totalKasbon += amount;
}

    });

    // =========================
    // SISA
    // =========================
let sisaPelunasan =
    grandTotal
    - totalDp
    - totalBahan
    - totalPelunasan
    - totalKasbon;
    // =========================
    // RENDER
    // =========================

    document.getElementById('paymentSummary').innerHTML = `

        <div>
            <b>Grand Total :</b>
            Rp ${formatRupiah(grandTotal)}
        </div>

        <div>
            <b>Total DP :</b>
            Rp ${formatRupiah(totalDp)}
        </div>

        <div>
            <b>Total Bahan :</b>
            Rp ${formatRupiah(totalBahan)}
        </div>
<div>
    <b>Total Kasbon :</b>
    <span style="color:red">
        Rp ${formatRupiah(totalKasbon)}
    </span>
</div>
        <div>
            <b>Total Pelunasan :</b>
            Rp ${formatRupiah(totalPelunasan)}
        </div>

       <hr>
<div style="
    margin-top:12px;
    padding:12px;
    border-radius:12px;
    background:#fff5f5;
    border:1px solid #fecaca;
">

    <!-- TITLE -->
    <div style="
        font-size:16px;
        color:#dc2626;
        font-weight:bold;
        margin-bottom:12px;
        display:flex;
        justify-content:space-between;
        align-items:center;
    ">

        <span>
            💰 Sisa Pelunasan :
            Rp ${formatRupiah(sisaPelunasan)}
        </span>



    `;
}
document.addEventListener('change', function(e){

    if(
        e.target.classList.contains(
            'payment-request-check'
        )
    ){

        let row =
            e.target.closest('.payment-row');

        savePaymentRequestRow(row);
    }
});
// realtime update
document.addEventListener('input', function(e){

    if(
        e.target.classList.contains('total-amount')
    ){
        updatePaymentSummary();
    }

    if(
        e.target.classList.contains('harga')
    ){
        updatePaymentSummary();
    }

    if(
        e.target.classList.contains('pcs')
    ){
        updatePaymentSummary();
    }

    if(
        e.target.classList.contains('set')
    ){
        updatePaymentSummary();
    }

});

document.addEventListener('change', function(e){

    if(
        e.target.classList.contains('payment-type')
    ){
        updatePaymentSummary();
    }

});

// load pertama
setTimeout(updatePaymentSummary, 300);



document.addEventListener('input', function(e) {

    if (e.target.classList.contains('total-amount')) {

       let value = e.target.innerText || '';

e.target.innerText = formatRupiah(value);

        placeCaretAtEnd(e.target);
    }
});

function placeCaretAtEnd(el) {

    el.focus();

    if (typeof window.getSelection != "undefined"
        && typeof document.createRange != "undefined") {

        let range = document.createRange();

        range.selectNodeContents(el);

        range.collapse(false);

        let sel = window.getSelection();

        sel.removeAllRanges();

        sel.addRange(range);
    }
}

</script>
<script>

document.getElementById('btnRiwayatSpk')
.addEventListener('click', function () {

    const spkId = document.getElementById('spk_id').value;

    if(!spkId){
        Swal.fire({
            icon:'warning',
            text:'SPK belum disimpan'
        });
        return;
    }

    fetch(`/spk/timeline/${spkId}`)
    .then(res => res.json())
    .then(data => {

        let html = '';

        if(!data.length){

            html = `
                <div class="text-center text-muted">
                    Belum ada riwayat
                </div>
            `;

        }else{

            data.forEach(item => {

                const row = item.data;

                let changesHtml = '';

                // UPDATE
                if(row.type === 'update'){

                    if(row.changes){

                     Object.entries(row.changes).forEach(([key,val]) => {

    let label = key;

    // =========================
    // PAYMENT LABEL
    // =========================
    if(key.includes('payments')){

        if(key.includes('amount')){
            label = '💰 Nominal Pembayaran';
        }

        else if(key.includes('date')){
            label = '📅 Tanggal Pembayaran';
        }

        else if(key.includes('note')){
            label = '📝 Jenis Pembayaran';
        }

        else if(key.includes('note_tambahan')){
            label = '📌 Keterangan Pembayaran';
        }

        else{
            label = '💳 Payment';
        }
    }

    // =========================
    // ITEMS LABEL
    // =========================
    if(key.includes('items')){

        if(key.includes('qty')){
            label = '📦 Qty Item';
        }

        else if(key.includes('harga')){
            label = '💰 Harga Item';
        }

        else if(key.includes('material')){
            label = '🪵 Material';
        }

        else{
            label = '📦 Item SPK';
        }
    }

    // =========================
    // NORMAL FIELD
    // =========================
    if(key === 'tgl_selesai'){
        label = '📅 Tanggal Selesai';
    }

    if(key === 'tgl_terima'){
        label = '📅 Tanggal Terima';
    }

    if(key === 'sup'){
        label = '👤 Supplier';
    }

    changesHtml += `

        <div style="
            margin-top:6px;
            padding:8px;
            background:#fff;
            border-radius:10px;
            font-size:12px;
        ">

            <div style="
                font-weight:bold;
                margin-bottom:4px;
            ">
                ${label}
            </div>

            <div>

                <span style="color:red">
                    ${formatTimelineValue(val.before)}
                </span>

                <span style="
                    margin:0 6px;
                    color:#999;
                ">
                    →
                </span>

                <span style="color:green">
                    ${formatTimelineValue(val.after)}
                </span>

            </div>

        </div>

    `;
});

                    }

                }

                html += `

                    <div style="
                        display:flex;
                        justify-content:flex-end;
                        margin-bottom:14px;
                    ">

                        <div style="
                            background:#dcf8c6;
                            max-width:75%;
                            padding:12px;
                            border-radius:12px;
                            box-shadow:0 1px 3px rgba(0,0,0,.15);
                            position:relative;
                        ">

                            <div style="
                                font-size:13px;
                                font-weight:bold;
                                margin-bottom:4px;
                            ">
                                ${row.user}
                            </div>

                            <div style="
                                font-size:13px;
                                margin-bottom:8px;
                            ">

                                ${
                                    row.type === 'create'
                                    ? 'Membuat SPK'
                                    : 'Mengupdate SPK'
                                }

                            </div>

                            ${changesHtml}

                            <div style="
                                text-align:right;
                                font-size:11px;
                                color:#666;
                                margin-top:8px;
                            ">

                                ${row.time}

                            </div>

                        </div>

                    </div>

                `;
            });

        }

        document.getElementById('timelineContainer')
        .innerHTML = html;

        $('#modalRiwayatSpk').modal('show');

    });
    function formatTimelineValue(value){

    if(value === null || value === undefined){
        return '-';
    }

    // ARRAY
    if(Array.isArray(value)){

        return value.map(item => {

            // payment object
            if(typeof item === 'object'){

                return Object.entries(item)
                    .map(([k,v]) => `${k}: ${v}`)
                    .join(', ');
            }

            return item;

        }).join('<br>');
    }

    // OBJECT
    if(typeof value === 'object'){

        return Object.entries(value)
            .map(([k,v]) => {

                // nested object
                if(typeof v === 'object'){

                    return `
                        <div style="margin-top:4px">
                            <b>${k}</b> :
                            ${JSON.stringify(v)}
                        </div>
                    `;
                }

                return `<b>${k}</b> : ${v}`;
            })
            .join('<br>');
    }

    return value;
}

});

</script>
<script>

const Toast = Swal.mixin({

    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 1500

});

// ==============================
// AUTO REQUEST CHECKBOX
// ==============================
document.addEventListener('change', function(e){

    if(!e.target.classList.contains('request-check'))
        return;

    // ==========================
    // GET CHECKED TYPE
    // ==========================
    let checkedTypes = [];

    document.querySelectorAll('.request-check:checked')
    .forEach(el => {

        checkedTypes.push(el.value);
    });

    // ==========================
    // GET PAYMENT SELECTED
    // ==========================
    let selectedPayments = [];

    document.querySelectorAll('.payment-row')
    .forEach(row => {

        let type =
            row.querySelector('.payment-type')?.value;

        // hanya yg dicentang
        if(checkedTypes.includes(type)){

            selectedPayments.push({

                date:
                    row.querySelector('.date-isian')
                    ?.innerText.trim() || '',

                note:type,

                amount:
                    (
                        row.querySelector('.total-amount')
                        ?.innerText || ''
                    ).replace(/\./g,''),

                note_tambahan:
                    row.querySelector('.note-tambahan')
                    ?.innerText.trim() || '',

                is_request:true
            });
        }
    });

    // ==========================
    // PAYLOAD
    // ==========================
    const payload = {

        spk_id:
            document.getElementById('spk_id')?.value,

        no_spk:
            document.querySelector('.no-spk')
            ?.innerText.trim(),

        checked_types: checkedTypes,

        payments:selectedPayments
    };

    console.log(payload);

    // ==========================
    // SAVE REQUEST
    // ==========================
    fetch('/payment-request/store', {

        method:'POST',

        headers:{
            'Content-Type':'application/json',
            'X-CSRF-TOKEN':'{{ csrf_token() }}'
        },

        body:JSON.stringify(payload)

    })
    .then(res => res.json())
    .then(res => {

        if(res.success){

            Toast.fire({
                icon:'success',
                title:'Request updated'
            });

        }else{

            Swal.fire({
                icon:'error',
                title:'Gagal',
                text:res.message || 'Gagal update request'
            });
        }
    })
    .catch(err => {

        console.error(err);

        Swal.fire({
            icon:'error',
            title:'Server Error',
            text:'Terjadi kesalahan server'
        });

    });

});

</script>
<script>

document.addEventListener('click', function(e){

    if(
        !e.target.classList.contains(
            'btn-status-spk'
        )
    ) return;

    let status =
        e.target.dataset.status;

    let spkId =
        document.getElementById('spk_id').value;

    Swal.fire({

        title:'Yakin?',

        text:
            'SPK akan diubah menjadi '
            + status,

        icon:'question',

        showCancelButton:true,

        confirmButtonText:'Ya',

        cancelButtonText:'Batal'

    }).then(result => {

        if(!result.isConfirmed)
            return;

        fetch(
            `/spk/change-status/${spkId}`,
        {

            method:'POST',

            headers:{

                'Content-Type':
                    'application/json',

                'X-CSRF-TOKEN':
                    '{{ csrf_token() }}'
            },

            body:JSON.stringify({

                status:status
            })
        })

        .then(res => res.json())

        .then(res => {

            if(res.success){

                Swal.fire({

                    icon:'success',

                    title:'Berhasil',

                    text:res.message,

                    timer:1200,

                    showConfirmButton:false
                });

                setTimeout(() => {

                    location.reload();

                },1000);

            }else{

                Swal.fire({

                    icon:'error',

                    title:'Gagal',

                    text:res.message
                });
            }
        })

        .catch(err => {

            console.error(err);

            Swal.fire({

                icon:'error',

                title:'Server Error'
            });
        });

    });

});

</script>
<script>

let customColumnCount = 0;

document.addEventListener('dblclick', function(e){

    // =========================
    // DOUBLE CLICK HEADER NAMA
    // =========================

    if(
        !e.target.classList.contains(
            'nama-header'
        )
    ){
        return;
    }

    customColumnCount++;

    const label =
        prompt('Nama Kolom');

    if(!label) return;

    // =========================
    // HEADER BARU
    // =========================

   const th =
    document.createElement('th');

th.innerText = label;

th.classList.add('spk-dynamic-header');

th.style.minWidth = '120px';

    // insert setelah nama
    e.target.after(th);

    // =========================
    // BODY
    // =========================

    document.querySelectorAll(
        'tr[data-detail-id]'
    )
    .forEach(row => {

        const namaTd =
            row.querySelector('.nama');

        if(!namaTd) return;

       const td =
    document.createElement('td');

td.contentEditable = true;

td.classList.add(
    'editable',
    'custom-column'
);

td.dataset.custom =
    customColumnCount;

td.style.minWidth = '120px';

        // insert setelah nama
        namaTd.after(td);

    });

});

</script>
<script>

let checkedTypesFromServer =
    @json($spk['checked_types'] ?? []);

console.log(checkedTypesFromServer);

</script>
<style>

.spk-dynamic-header{

    background:#2f437f !important;

    color:white;

    font-weight:bold;

    text-align:center;

    vertical-align:middle;

    white-space:nowrap;
}

</style>
@endsection
