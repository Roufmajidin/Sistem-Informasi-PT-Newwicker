<tr class="text-center spk-header main-header">

    <th>Article Nr</th>

    <th>Gambar</th>

    <th class="nama-header"
        style="cursor:pointer">

        Nama

    </th>

    {{-- CUSTOM HEADER --}}
    @foreach($spk['custom_headers'] ?? [] as $header)

        <th class="spk-dynamic-header"
            data-custom="{{ $header['key'] ?? '' }}">

            {{ $header['label'] ?? '' }}

        </th>

    @endforeach

    <th>P</th>
    <th>L</th>
    <th>T</th>

    <th>Material</th>

    <th>PCS</th>

    <th>SET</th>

    <th width="90">Harga</th>

    <th width="90">Total</th>

    <th>Catatan</th>

</tr>
