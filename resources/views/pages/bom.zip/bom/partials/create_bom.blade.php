<div class="container-fluid">
    {{-- HEADER BOM --}}
    <div class="card mb-3">
        <div class="card-header">
    @if(isset($bom))

            <h5>EDIT BOM</h5>
            @else
            <h5>Create BOM</h5>
            @endif
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <table class="table table-bordered">
                        <tr>
                            <th width="200">ITEM</th>
                            <td>
                                <input type="text" class="form-control" name="item">
                            </td>
                        </tr>
                        <tr>
                            <th>ARTICLE CODE</th>
                            <td>
                                <input type="text" class="form-control" name="article_code">
                            </td>
                        </tr>
                        <tr>
                            <th>DIMENSION</th>
                            <td>
                                <div class="row">
                                    <div class="col-md-4">
                                        <input type="number" class="form-control" name="panjang" placeholder="Panjang">
                                    </div>
                                    <div class="col-md-4">
                                        <input type="number" class="form-control" name="lebar" placeholder="Lebar">
                                    </div>
                                    <div class="col-md-4">
                                        <input type="number" class="form-control" name="tinggi" placeholder="Tinggi">
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>CARTON SIZE</th>
                            <td>
                                <div class="row">
                                    <div class="col-md-4">
                                        <input type="number" class="form-control" placeholder="Panjang"
                                            name="carton_panjang">
                                    </div>
                                    <div class="col-md-4">
                                        <input type="number" class="form-control" placeholder="Lebar"
                                            name="carton_lebar">
                                    </div>
                                    <div class="col-md-4">
                                        <input type="number" class="form-control" placeholder="Tinggi"
                                            name="carton_tinggi">
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>LOADABILITY</th>
                            <td>
                                <div class="row">

                                    <div class="col-md-6">

                                        <input type="number" name="loadability_pcs" class="form-control"
                                            placeholder="PCS">

                                    </div>

                                    <div class="col-md-6">

                                        <input type="number" step="0.001" name="loadability_cbm" class="form-control"
                                            placeholder="CBM">

                                    </div>

                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-4">

                    <div class="border p-3 text-center">

                        <input type="file" id="bom_image" name="image" accept="image/*" class="form-control mb-2">

                        <img id="preview" src="https://placehold.co/300x200" class="img-fluid border">

                    </div>

                </div>
            </div>
        </div>
    </div>
    {{-- LABOUR & MATERIAL --}}
    @if(isset($bom))

        <button type="button" class="btn btn-warning btn-sm" id="btn-update-bom">

            Update BOM

        </button>

    @else

        <button type="button" class="btn btn-primary btn-sm" id="btn-save-bom">

            Save BOM

        </button>

    @endif
    <div class="card">
        <div class="card-header bg-success text-white">
            <div class="d-flex justify-content-between">
                <strong>LABOUR & MATERIAL</strong>
                <button type="button" class="btn btn-light btn-sm" id="btn-add-header">
                    + Add Header
                </button>
            </div>
        </div>
        <div class="card-body">
            <div id="bom-sections">
                {{-- SECTION DINAMIS DISINI --}}
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="materialPickerModal">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5>
                    Pilih Material
                </h5>
            </div>
            <div class="modal-body">
                <input type="text" id="searchMasterMaterial" class="form-control mb-3" placeholder="Cari material...">
                <table class="table table-bordered" id="materialMasterTable">
                    <thead>
                        <tr>
                            <th width="80">
                                Pilih
                            </th>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Jenis</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($masterMaterials as $item)
                            <tr>
                                <td>
                                    <button type="button" class="btn btn-primary btn-sm btn-select-material"
                                        data-id="{{ $item->id }}" data-name="{{ $item->nama }}"
                                        data-type="{{ $item->type }}">
                                        Pilih
                                    </button>
                                </td>
                                <td>
                                    {{ $item->id }}
                                </td>
                                <td>
                                    {{ $item->nama }}
                                </td>
                                <td>
                                    {{ $item->jenis }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    let activeMaterialInput = null;
    let sectionIndex = 0;
    // klik child
    $(document).on(
        'click',
        '.material-picker',
        function () {
            activeMaterialInput = $(this);
            $('#materialPickerModal')
                .modal('show');
        });
    // pili material dari modal
    $(document).on(
        'click',
        '.btn-select-material',
        function () {
            let id =
                $(this).data('id');
            let nama =
                $(this).data('name');
            let type =
                $(this).data('type');
            activeMaterialInput.val(nama);
            activeMaterialInput
                .siblings('.material-id')
                .val(id);
            activeMaterialInput
                .siblings('.material-type')
                .val(type);
            $('#materialPickerModal')
                .modal('hide');
        });
    // search material di modal
    $('#searchMasterMaterial').on(
        'keyup',
        function () {
            let keyword =
                $(this)
                .val()
                .toLowerCase();
            $('#materialMasterTable tbody tr')
                .each(function () {
                    let text =
                        $(this)
                        .text()
                        .toLowerCase();
                    $(this)
                        .toggle(
                            text.indexOf(keyword) > -1
                        );
                });
        });
    // ADD HEADER
    $('#btn-add-header').click(function () {
        sectionIndex++;
        let html = `
        <div class="bom-section card mb-3">
            <div class="card-header bg-success text-white">
                <div class="row">
                    <div class="col-md-8">
                        <input
                            type="text"
                            class="form-control section-name"
                            placeholder="Nama Header"
                            value="RANGKA ROTAN">
                    </div>
                    <div class="col-md-4 text-right">
                        <button
                            type="button"
                            class="btn btn-primary btn-sm btn-add-child">
                            Add Child
                        </button>
                        <button
                            type="button"
                            class="btn btn-danger btn-sm btn-remove-header">
                            Delete Header
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th width="35%">Material</th>
                            <th width="20%">Spesifikasi</th>
                            <th width="15%">Qty</th>
                            <th width="15%">Satuan</th>
                            <th width="15%">Action</th>
                        </tr>
                    </thead>
                    <tbody class="child-body">
                    </tbody>
                </table>
            </div>
        </div>
    `;
        $('#bom-sections').append(html);
        saveDraft();
    });
    // REMOVE HEADER
    $(document).on(
        'click',
        '.btn-remove-header',
        function () {
            $(this)
                .closest('.bom-section')
                .remove();
            saveDraft();
        });
    // ADD CHILD
    $(document).on(
        'click',
        '.btn-add-child',
        function () {
            let tbody = $(this)
                .closest('.bom-section')
                .find('.child-body');
            let row = `
<tr>
    <td>
        <input
            type="hidden"
            class="material-id">
        <input
            type="hidden"
            class="material-type">
        <input
            type="text"
            readonly
            class="form-control material-picker"
            placeholder="Klik untuk pilih material">
    </td>
    <td>
        <input
            type="text"
            class="form-control specification"
            placeholder="Spesifikasi">
    </td>
    <td>
        <input
            type="number"
            step="0.0001"
            class="form-control qty"
            placeholder="Qty">
    </td>
    <td>
        <input
            type="text"
            class="form-control unit"
            placeholder="Kg / pcs / m3">
    </td>
    <td>
        <button
            type="button"
            class="btn btn-danger btn-sm btn-remove-child">
            Delete
        </button>
    </td>
</tr>
`;
            tbody.append(row);
            saveDraft();
        });
    // REMOVE CHILD
    $(document).on(
        'click',
        '.btn-remove-child',
        function () {
            $(this)
                .closest('tr')
                .remove();
        });
    // save bom
    $('#btn-save-bom').click(function () {

        let formData = new FormData();

        formData.append(
            '_token',
            '{{ csrf_token() }}'
        );

        formData.append(
            'bom',
            JSON.stringify(
                collectBomData()
            )
        );

        let image =
            $('#bom_image')[0]
            .files[0];

        if (image) {

            formData.append(
                'image',
                image
            );

        }

        $.ajax({

            url: "{{ route('bom.store') }}",

            type: 'POST',

            data: formData,

            processData: false,

            contentType: false,

            success: function (res) {

                alert(
                    'BOM berhasil disimpan'
                );

            }

        });

    });

    function saveDraft() {
        let draft = collectBomData();
        localStorage.setItem(
            'bom_draft',
            JSON.stringify(draft)
        );
    }
    $(document).on(
        'keyup change',
        'input,textarea,select',
        function () {
            saveDraft();
        });
    $(document).ready(function () {
        let draft =
            localStorage.getItem(
                'bom_draft'
            );
        if (!draft) {
            return;
        }
        draft =
            JSON.parse(draft);
        console.log(draft);
    });

    function renderDraft(draft) {
        $('#bom-sections').html('');
        draft.groups.forEach(function (group) {
            let html = `
            <div class="bom-section card mb-3">
                <div class="card-header bg-success text-white">
                    <div class="row">
                        <div class="col-md-8">
                            <input
                                type="text"
                                class="form-control section-name"
                                value="${group.name}">
                        </div>
                        <div class="col-md-4 text-right">
                            <button
                                type="button"
                                class="btn btn-primary btn-sm btn-add-child">
                                Add Child
                            </button>
                            <button
                                type="button"
                                class="btn btn-danger btn-sm btn-remove-header">
                                Delete Header
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
              
                    <thead>
                            <tr>
                                <th>Material</th>
                                <th>Spesifikasi</th>
                                <th>Qty</th>
                                <th>Satuan</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="child-body">
                        </tbody>
                    </table>
                </div>
            </div>
        `;
            $('#bom-sections').append(html);
            let tbody =
                $('#bom-sections')
                .find('.child-body')
                .last();
            console.log(group.items);
            group.items.forEach(function (item) {
                tbody.append(`
                <tr>
                    <td>
                        <input
                            type="hidden"
                            class="material-id"
                            value="${item.material_id || ''}">
                        <input
                            type="hidden"
                            class="material-type"
                            value="${item.material_type || ''}">
                        <input
                            type="text"
                            readonly
                            class="form-control material-picker"
                            value="${item.name || ''}">
                    </td>
                    <td>
                        <input
                            type="text"
                            class="form-control specification"
                            value="${item.notes || ''}">
                    </td>
                    <td>
                        <input
                            type="number"
                            class="form-control qty"
                            value="${item.qty || ''}">
                    </td>
                    <td>
                        <input
                            type="text"
                            class="form-control unit"
                            value="${item.unit || ''}">
                    </td>
                    <td>
                        <button
                            type="button"
                            class="btn btn-danger btn-sm btn-remove-child">
                            Delete
                        </button>
                    </td>
                </tr>
            `);
            });
        });
    }

    function collectBomData() {
        let groups = [];
        $('.bom-section').each(function () {
            let group = {
                name: $(this)
                    .find('.section-name')
                    .val(),
                items: []
            };
            $(this)
                .find('.child-body tr')
                .each(function () {
                    group.items.push({
                        material_id: $(this)
                            .find('.material-id')
                            .val(),
                        material_type: $(this)
                            .find('.material-type')
                            .val(),
                        name: $(this)
                            .find('.material-picker')
                            .val(),
                        qty: $(this)
                            .find('.qty')
                            .val(),
                        unit: $(this)
                            .find('.unit')
                            .val(),
                        notes: $(this)
                            .find('.specification')
                            .val()
                    });
                });
            groups.push(group);
        });
        return {

            name: $('[name="item"]').val(),

            article_number: $('[name="article_code"]').val(),

            panjang: $('[name="panjang"]').val(),

            lebar: $('[name="lebar"]').val(),

            tinggi: $('[name="tinggi"]').val(),

            carton_panjang: $('[name="carton_panjang"]').val(),

            carton_lebar: $('[name="carton_lebar"]').val(),

            carton_tinggi: $('[name="carton_tinggi"]').val(),

            loadability_pcs: $('[name="loadability_pcs"]').val(),

            loadability_cbm: $('[name="loadability_cbm"]').val(),

            groups: groups

        };
    }
    $(document).ready(function () {
        let draft = localStorage.getItem('bom_draft');
        if (!draft) {
            return;
        }
        draft = JSON.parse(draft);
        console.log('draft loaded', draft);
        renderDraft(draft);
    });

    // edit bom
    $(document).on(
        'click',
        '#btn-update-bom',
        function () {

            let formData =
                new FormData();

            formData.append(
                '_token',
                '{{ csrf_token() }}'
            );

            formData.append(
                'bom',
                JSON.stringify(
                    collectBomData()
                )
            );

            let image =
                $('#bom_image')[0]
                .files[0];

            if (image) {

                formData.append(
                    'image',
                    image
                );

            }

            $.ajax({

                url: '/bom/update/' + bomId,

                type: 'POST',

                data: formData,

                processData: false,

                contentType: false,

                success: function (res) {

                    alert(
                        'BOM berhasil diupdate'
                    );

                },

                error: function (xhr) {

                    console.log(
                        xhr.responseText
                    );

                }

            });

        });

</script>
<script>
    $('#bom_image').on(
        'change',
        function (e) {

            let file =
                e.target.files[0];

            if (!file) {
                return;
            }

            let reader =
                new FileReader();

            reader.onload =
                function (event) {

                    $('#preview').attr(
                        'src',
                        event.target.result
                    );

                };

            reader.readAsDataURL(
                file
            );

        }
    );

</script>
