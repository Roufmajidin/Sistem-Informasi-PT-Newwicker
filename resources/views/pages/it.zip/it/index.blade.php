@extends('master.master')

@section('content')

<div class="container-fluid px-4 py-3">

    {{-- ========================================================= --}}
    {{-- TAB NAVIGATION --}}
    {{-- ========================================================= --}}

    <div class="card border-0 shadow-sm mb-4" style="margin-top:20px">

        <div class="card-body pb-0">

            <ul class="nav nav-tabs border-0">

                <li class="nav-item">

                    <button
                        class="nav-link active"
                        data-bs-toggle="tab"
                        data-bs-target="#web-monitoring"
                        type="button">

                        <i class="bi bi-globe me-1"></i>
                        Web Monitoring

                    </button>

                </li>

                <li class="nav-item">

                    <button
                        class="nav-link"
                        data-bs-toggle="tab"
                        data-bs-target="#apps-monitoring"
                        type="button">

                        <i class="bi bi-phone me-1"></i>
                        Apps Monitoring

                    </button>

                </li>

            </ul>

        </div>

    </div>


    <div class="tab-content">


        {{-- ========================================================= --}}
        {{-- WEB MONITORING --}}
        {{-- ========================================================= --}}

        <div
            class="tab-pane fade show active"
            id="web-monitoring">

            {{-- HEADER --}}

           @section('btn')
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">

                <div>

                    <h5 class="fw-bold mb-1 text-dark">
                        IT Dashboard
                    </h5>

                    <p class="text-muted mb-0 small">
                        Web user activity monitoring
                    </p>

                </div>

            </div>
           
           @endsection


            {{-- ===================================================== --}}
            {{-- WEB SUMMARY CARDS --}}
            {{-- ===================================================== --}}

            <div class="row g-3 mb-4">

                {{-- TOTAL ACTIVITY --}}

                <div class="col-12 col-sm-6 col-xl-3">

                    <div class="card border-0 shadow-sm h-100 rounded-3">

                        <div class="card-body p-3 d-flex align-items-center gap-3">

                            <div class="metric-icon bg-primary bg-opacity-10 text-primary">

                                <i class="bi bi-activity fs-4"></i>

                            </div>

                            <div>

                                <span class="text-muted small fw-semibold d-block">
                                    Total Activity
                                </span>

                                <h4 class="fw-bold mb-0 text-dark">
                                    {{ number_format($totalActivity) }}
                                </h4>

                                <span class="text-muted small">
                                    All web activity
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- ACTIVE USERS --}}

                <div class="col-12 col-sm-6 col-xl-3">

                    <div class="card border-0 shadow-sm h-100 rounded-3">

                        <div class="card-body p-3 d-flex align-items-center gap-3">

                            <div class="metric-icon bg-success bg-opacity-10 text-success">

                                <i class="bi bi-people fs-4"></i>

                            </div>

                            <div>

                                <span class="text-muted small fw-semibold d-block">
                                    Active Users
                                </span>

                                <h4 class="fw-bold mb-0 text-dark">
                                    {{ number_format($activeUsers) }}
                                </h4>

                                <span class="text-muted small">
                                    Active today
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- ACTIVITY TODAY --}}

                <div class="col-12 col-sm-6 col-xl-3">

                    <div class="card border-0 shadow-sm h-100 rounded-3">

                        <div class="card-body p-3 d-flex align-items-center gap-3">

                            <div class="metric-icon bg-warning bg-opacity-10 text-warning">

                                <i class="bi bi-calendar-check fs-4"></i>

                            </div>

                            <div>

                                <span class="text-muted small fw-semibold d-block">
                                    Activity Today
                                </span>

                                <h4 class="fw-bold mb-0 text-dark">
                                    {{ number_format($todayActivity) }}
                                </h4>

                                <span class="text-muted small">
                                    Today's activity
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- MOST ACTIVE USER --}}

                <div class="col-12 col-sm-6 col-xl-3">

                    <div class="card border-0 shadow-sm h-100 rounded-3">

                        <div class="card-body p-3 d-flex align-items-center gap-3">

                            <div class="metric-icon bg-danger bg-opacity-10 text-danger">

                                <i class="bi bi-person-check fs-4"></i>

                            </div>

                            <div class="overflow-hidden">

                                <span class="text-muted small fw-semibold d-block">
                                    Most Active User
                                </span>

                                @if($mostActiveUser)

                                    <h5 class="fw-bold mb-0 text-dark text-truncate">

                                        {{ $mostActiveUser->user->name ?? '-' }}

                                    </h5>

                                    <span class="text-muted small">

                                        {{ number_format($mostActiveUser->total_activity) }}
                                        activities / 7 days

                                    </span>

                                @else

                                    <h5 class="fw-bold mb-0">
                                        -
                                    </h5>

                                @endif

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            {{-- ===================================================== --}}
            {{-- WEB CHARTS --}}
            {{-- ===================================================== --}}

            <div class="row g-3 mb-4">


                {{-- ACTIVITY PER DAY --}}

                <div class="col-12 col-lg-8">

                    <div class="card border-0 shadow-sm rounded-3 h-100">

                        <div class="card-header bg-white py-3 border-0">

                            <strong>
                                User Activity
                            </strong>

                            <div class="text-muted small">
                                Activity 7 hari terakhir
                            </div>

                        </div>

                        <div class="card-body">

                            <div
                                id="activityByDayChart"
                                style="height:360px;">
                            </div>

                        </div>

                    </div>

                </div>


                {{-- ACTIVITY MODULE --}}

                <div class="col-12 col-lg-4" >

                    <div class="card border-0 shadow-sm rounded-3 h-100">

                        <div class="card-header bg-white py-3 border-0">

                            <strong>
                                Activity by Module
                            </strong>

                            <div class="text-muted small">
                                30 hari terakhir
                            </div>

                        </div>

                        <div class="card-body">

                            <div
                                id="activityByModuleChart"
                                style="height:260px;">
                            </div>

                            <div class="mt-2 small" style="padding: 20px">

                                @foreach($activityByModule as $module)

                                    <div class="d-flex justify-content-between mb-1">

                                        <span>
                                            {{ $module['name'] }}
                                        </span>

                                        <span class="fw-bold">
                                            {{ number_format($module['total']) }}
                                        </span>

                                    </div>

                                @endforeach

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            {{-- ===================================================== --}}
            {{-- WEB ACTIVITY TABLE --}}
            {{-- ===================================================== --}}

            <div class="card border-0 shadow-sm rounded-3 mb-4">

                <div class="card-header bg-white py-3 border-0">

                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">

                        <div>

                            <h6 class="fw-bold mb-0">
                                User Activity
                            </h6>

                            <small class="text-muted">
                                Latest 500 activity
                            </small>

                        </div>


                        <div style="width:280px;">

                            <div class="input-group input-group-sm">

                                <span class="input-group-text bg-white">

                                    <i class="bi bi-search"></i>

                                </span>

                                <input
                                    type="text"
                                    id="searchUser"
                                    class="form-control"
                                    placeholder="Search user..."
                                    autocomplete="off">

                            </div>

                        </div>

                    </div>

                </div>


                <div class="card-body p-0">

                    <div class="it-table-wrapper">

                        <table
                            class="table table-hover table-bordered align-middle mb-0"
                            id="activityTable">

                            <thead>

                                <tr>

                                    <th style="width:60px;">
                                        No
                                    </th>

                                    <th>
                                        User
                                    </th>

                                    <th>
                                        Route
                                    </th>

                                    <th>
                                        URL
                                    </th>

                                    <th class="text-center">
                                        Method
                                    </th>

                                    <th>
                                        IP Address
                                    </th>

                                    <th>
                                        Time
                                    </th>

                                </tr>

                            </thead>


                            <tbody>

                                @forelse($activities as $index => $activity)

                                    <tr class="activity-row">

                                        <td class="text-center">
                                            {{ $index + 1 }}
                                        </td>

                                        <td>

                                            <strong class="user-name">

                                                {{ $activity->user->name ?? '-' }}

                                            </strong>

                                        </td>

                                        <td>

                                            <span class="badge bg-secondary">

                                                {{ $activity->route_name ?? '-' }}

                                            </span>

                                        </td>

                                        <td>

                                            <code>

                                                {{ $activity->url }}

                                            </code>

                                        </td>

                                        <td class="text-center">

                                            @if($activity->method === 'GET')

                                                <span class="badge bg-success">
                                                    GET
                                                </span>

                                            @elseif($activity->method === 'POST')

                                                <span class="badge bg-primary">
                                                    POST
                                                </span>

                                            @elseif(
                                                $activity->method === 'PUT' ||
                                                $activity->method === 'PATCH'
                                            )

                                                <span class="badge bg-warning text-dark">
                                                    {{ $activity->method }}
                                                </span>

                                            @elseif($activity->method === 'DELETE')

                                                <span class="badge bg-danger">
                                                    DELETE
                                                </span>

                                            @else

                                                <span class="badge bg-secondary">
                                                    {{ $activity->method }}
                                                </span>

                                            @endif

                                        </td>

                                        <td>
                                            {{ $activity->ip_address ?? '-' }}
                                        </td>

                                        <td>

                                            <div>
                                                {{ $activity->created_at?->format('d M Y') }}
                                            </div>

                                            <small class="text-muted">
                                                {{ $activity->created_at?->format('H:i:s') }}
                                            </small>

                                        </td>

                                    </tr>

                                @empty

                                    <tr>

                                        <td
                                            colspan="7"
                                            class="text-center py-5 text-muted">

                                            Belum ada activity.

                                        </td>

                                    </tr>

                                @endforelse

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>


        {{-- ========================================================= --}}
        {{-- APPS MONITORING --}}
        {{-- ========================================================= --}}

        <div
            class="tab-pane fade"
            id="apps-monitoring">


            {{-- HEADER --}}

            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">

                <div>

                    <h5 class="fw-bold mb-1 text-dark">
                        Apps Monitoring
                    </h5>

                    <p class="text-muted mb-0 small">
                        QC Application API activity monitoring
                    </p>

                </div>

            </div>


            {{-- ===================================================== --}}
            {{-- API SUMMARY CARDS --}}
            {{-- ===================================================== --}}

            <div class="row g-3 mb-4">


                {{-- API ACTIVITY --}}

                <div class="col-12 col-sm-6 col-xl-3">

                    <div class="card border-0 shadow-sm h-100 rounded-3">

                        <div class="card-body p-3 d-flex align-items-center gap-3">

                            <div class="metric-icon bg-primary bg-opacity-10 text-primary">

                                <i class="bi bi-phone fs-4"></i>

                            </div>

                            <div>

                                <span class="text-muted small fw-semibold d-block">
                                    API Activity
                                </span>

                                <h4 class="fw-bold mb-0 text-dark">
                                    {{ number_format($totalApiActivity) }}
                                </h4>

                                <span class="text-muted small">
                                    All API requests
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- ACTIVE API USERS --}}

                <div class="col-12 col-sm-6 col-xl-3">

                    <div class="card border-0 shadow-sm h-100 rounded-3">

                        <div class="card-body p-3 d-flex align-items-center gap-3">

                            <div class="metric-icon bg-success bg-opacity-10 text-success">

                                <i class="bi bi-people fs-4"></i>

                            </div>

                            <div>

                                <span class="text-muted small fw-semibold d-block">
                                    Active Users
                                </span>

                                <h4 class="fw-bold mb-0 text-dark">
                                    {{ number_format($activeApiUsers) }}
                                </h4>

                                <span class="text-muted small">
                                    API users today
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- API TODAY --}}

                <div class="col-12 col-sm-6 col-xl-3">

                    <div class="card border-0 shadow-sm h-100 rounded-3">

                        <div class="card-body p-3 d-flex align-items-center gap-3">

                            <div class="metric-icon bg-warning bg-opacity-10 text-warning">

                                <i class="bi bi-calendar-check fs-4"></i>

                            </div>

                            <div>

                                <span class="text-muted small fw-semibold d-block">
                                    API Today
                                </span>

                                <h4 class="fw-bold mb-0 text-dark">
                                    {{ number_format($todayApiActivity) }}
                                </h4>

                                <span class="text-muted small">
                                    Requests today
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- MOST USED API --}}

                <div class="col-12 col-sm-6 col-xl-3">

                    <div class="card border-0 shadow-sm h-100 rounded-3">

                        <div class="card-body p-3 d-flex align-items-center gap-3">

                            <div class="metric-icon bg-danger bg-opacity-10 text-danger">

                                <i class="bi bi-bar-chart fs-4"></i>

                            </div>

                            <div class="overflow-hidden">

                                <span class="text-muted small fw-semibold d-block">
                                    Most Used API
                                </span>

                                @if($mostUsedApi)

                                    <h6
                                        class="fw-bold mb-0 text-dark text-truncate"
                                        title="{{ $mostUsedApi->url }}">

                                        {{ $mostUsedApi->url }}

                                    </h6>

                                    <small class="text-muted">

                                        {{ number_format($mostUsedApi->total) }}
                                        requests

                                    </small>

                                @else

                                    <h6 class="fw-bold mb-0">
                                        -
                                    </h6>

                                @endif

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            {{-- ===================================================== --}}
            {{-- API CHARTS --}}
            {{-- ===================================================== --}}

            <div class="row g-3 mb-4">


                {{-- API ACTIVITY 7 DAYS --}}

                <div class="col-12 col-lg-8">

                    <div class="card border-0 shadow-sm rounded-3 h-100">

                        <div class="card-header bg-white py-3 border-0">

                            <strong>
                                API Activity
                            </strong>

                            <div class="text-muted small">
                                API request 7 hari terakhir
                            </div>

                        </div>

                        <div class="card-body">

                            <div
                                id="apiActivityByDayChart"
                                style="height:360px;">
                            </div>

                        </div>

                    </div>

                </div>


                {{-- API ENDPOINT --}}

                <div class="col-12 col-lg-4">

                    <div class="card border-0 shadow-sm rounded-3 h-100">

                        <div class="card-header bg-white py-3 border-0">

                            <strong>
                                API Endpoint Usage
                            </strong>

                            <div class="text-muted small">
                                Most frequently called
                            </div>

                        </div>

                        <div class="card-body">

                            <div
                                id="apiEndpointChart"
                                style="height:360px;">
                            </div>

                        </div>

                    </div>

                </div>

            </div>


            {{-- ===================================================== --}}
            {{-- API ACTIVITY TABLE --}}
            {{-- ===================================================== --}}

            <div class="card border-0 shadow-sm rounded-3 mb-4">

                <div class="card-header bg-white py-3 border-0">

                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">

                        <div>

                            <h6 class="fw-bold mb-0">
                                Apps Activity
                            </h6>

                            <small class="text-muted">
                                Latest 500 API activity
                            </small>

                        </div>


                        <div style="width:280px;">

                            <div class="input-group input-group-sm">

                                <span class="input-group-text bg-white">

                                    <i class="bi bi-search"></i>

                                </span>

                                <input
                                    type="text"
                                    id="searchAppUser"
                                    class="form-control"
                                    placeholder="Search user..."
                                    autocomplete="off">

                            </div>

                        </div>

                    </div>

                </div>


                <div class="card-body p-0">

                    <div class="it-table-wrapper">

                        <table class="table table-hover table-bordered align-middle mb-0">

                            <thead>

                                <tr>

                                    <th style="width:60px;">
                                        No
                                    </th>

                                    <th>
                                        User
                                    </th>

                                    <th>
                                        Endpoint
                                    </th>

                                    <th class="text-center">
                                        Method
                                    </th>

                                    <th>
                                        IP Address
                                    </th>

                                    <th>
                                        User Agent
                                    </th>

                                    <th>
                                        Time
                                    </th>

                                </tr>

                            </thead>


                            <tbody>

                                @forelse($appActivities as $index => $activity)

                                    <tr class="app-activity-row">

                                        <td class="text-center">
                                            {{ $index + 1 }}
                                        </td>

                                        <td>

                                            <strong class="app-user-name">

                                                {{ $activity->user->name ?? '-' }}

                                            </strong>

                                        </td>

                                        <td>

                                            <code>
                                                {{ $activity->url }}
                                            </code>

                                        </td>

                                        <td class="text-center">

                                            @if($activity->method === 'GET')

                                                <span class="badge bg-success">
                                                    GET
                                                </span>

                                            @elseif($activity->method === 'POST')

                                                <span class="badge bg-primary">
                                                    POST
                                                </span>

                                            @elseif(
                                                $activity->method === 'PUT' ||
                                                $activity->method === 'PATCH'
                                            )

                                                <span class="badge bg-warning text-dark">
                                                    {{ $activity->method }}
                                                </span>

                                            @elseif($activity->method === 'DELETE')

                                                <span class="badge bg-danger">
                                                    DELETE
                                                </span>

                                            @else

                                                <span class="badge bg-secondary">
                                                    {{ $activity->method }}
                                                </span>

                                            @endif

                                        </td>

                                        <td>
                                            {{ $activity->ip_address ?? '-' }}
                                        </td>

                                        <td
                                            style="max-width:250px;"
                                            class="text-truncate"
                                            title="{{ $activity->user_agent }}">

                                            {{ $activity->user_agent ?? '-' }}

                                        </td>

                                        <td>

                                            <div>
                                                {{ $activity->created_at?->format('d M Y') }}
                                            </div>

                                            <small class="text-muted">
                                                {{ $activity->created_at?->format('H:i:s') }}
                                            </small>

                                        </td>

                                    </tr>

                                @empty

                                    <tr>

                                        <td
                                            colspan="7"
                                            class="text-center py-5 text-muted">

                                            <i class="bi bi-phone fs-3 d-block mb-2"></i>

                                            Belum ada API activity.

                                        </td>

                                    </tr>

                                @endforelse

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


{{-- ============================================================= --}}
{{-- APEXCHARTS --}}
{{-- ============================================================= --}}

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>


<script>

    /*
    |--------------------------------------------------------------------------
    | WEB - ACTIVITY BY DAY
    |--------------------------------------------------------------------------
    */

    const activityByDay = @json($activityByDay);

    const activityDayLabels = activityByDay.map(
        item => item.label
    );

    const activityDayValues = activityByDay.map(
        item => Number(item.total)
    );


    new ApexCharts(

        document.querySelector(
            "#activityByDayChart"
        ),

        {

            series: [

                {
                    name: 'Activity',
                    data: activityDayValues
                }

            ],

            chart: {

                type: 'area',

                height: 360,

                toolbar: {
                    show: false
                },

                zoom: {
                    enabled: false
                }

            },

            stroke: {

                curve: 'smooth',

                width: 3

            },

            fill: {

                opacity: 0.15

            },

            markers: {

                size: 5

            },

            xaxis: {

                categories: activityDayLabels,

                title: {
                    text: 'Tanggal'
                }

            },

            yaxis: {

                title: {
                    text: 'Jumlah Activity'
                },

                labels: {

                    formatter: function(value) {

                        return Number(value)
                            .toLocaleString('id-ID');

                    }

                }

            },

            tooltip: {

                y: {

                    formatter: function(value) {

                        return Number(value)
                            .toLocaleString('id-ID')
                            + ' activity';

                    }

                }

            },

            dataLabels: {
                enabled: false
            },

            legend: {
                position: 'top'
            }

        }

    ).render();


    /*
    |--------------------------------------------------------------------------
    | WEB - ACTIVITY BY MODULE
    |--------------------------------------------------------------------------
    */

    const activityByModule = @json($activityByModule);

    const moduleLabels = activityByModule.map(
        item => item.name
    );

    const moduleValues = activityByModule.map(
        item => Number(item.total)
    );


    new ApexCharts(

        document.querySelector(
            "#activityByModuleChart"
        ),

        {

            series: moduleValues,

            labels: moduleLabels,

            chart: {

                type: 'donut',

                height: 260

            },

            legend: {

                position: 'bottom',

                fontSize: '11px'

            },

            dataLabels: {

                enabled: true,

                formatter: function(value) {

                    return value.toFixed(1) + '%';

                }

            },

            tooltip: {

                y: {

                    formatter: function(value) {

                        return Number(value)
                            .toLocaleString('id-ID')
                            + ' activity';

                    }

                }

            }

        }

    ).render();


    /*
    |--------------------------------------------------------------------------
    | APPS - ACTIVITY BY DAY
    |--------------------------------------------------------------------------
    */

    const apiActivityByDay = @json($apiActivityByDay);

    const apiDayLabels = apiActivityByDay.map(
        item => item.label
    );

    const apiDayValues = apiActivityByDay.map(
        item => Number(item.total)
    );


    new ApexCharts(

        document.querySelector(
            "#apiActivityByDayChart"
        ),

        {

            series: [

                {
                    name: 'API Requests',
                    data: apiDayValues
                }

            ],

            chart: {

                type: 'area',

                height: 360,

                toolbar: {
                    show: false
                },

                zoom: {
                    enabled: false
                }

            },

            stroke: {

                curve: 'smooth',

                width: 3

            },

            fill: {

                opacity: 0.15

            },

            markers: {

                size: 5

            },

            xaxis: {

                categories: apiDayLabels,

                title: {
                    text: 'Tanggal'
                }

            },

            yaxis: {

                title: {
                    text: 'API Requests'
                },

                labels: {

                    formatter: function(value) {

                        return Number(value)
                            .toLocaleString('id-ID');

                    }

                }

            },

            tooltip: {

                y: {

                    formatter: function(value) {

                        return Number(value)
                            .toLocaleString('id-ID')
                            + ' requests';

                    }

                }

            },

            dataLabels: {
                enabled: false
            },

            legend: {
                position: 'top'
            }

        }

    ).render();


    /*
    |--------------------------------------------------------------------------
    | APPS - ENDPOINT USAGE
    |--------------------------------------------------------------------------
    */

    const apiEndpointUsage = @json($apiEndpointUsage);

    const endpointLabels = apiEndpointUsage.map(
        item => item.url
    );

    const endpointValues = apiEndpointUsage.map(
        item => Number(item.total)
    );


    new ApexCharts(

        document.querySelector(
            "#apiEndpointChart"
        ),

        {

            series: [

                {
                    name: 'Requests',
                    data: endpointValues
                }

            ],

            chart: {

                type: 'bar',

                height: 360,

                toolbar: {
                    show: false
                }

            },

            plotOptions: {

                bar: {

                    horizontal: true,

                    borderRadius: 4

                }

            },

            xaxis: {

                categories: endpointLabels

            },

            tooltip: {

                y: {

                    formatter: function(value) {

                        return Number(value)
                            .toLocaleString('id-ID')
                            + ' requests';

                    }

                }

            },

            dataLabels: {

                enabled: false

            }

        }

    ).render();

</script>


{{-- ============================================================= --}}
{{-- SEARCH WEB USER --}}
{{-- ============================================================= --}}

<script>

    const searchUser = document.getElementById('searchUser');

    if (searchUser) {

        searchUser.addEventListener('keyup', function() {

            const keyword = this.value
                .toLowerCase()
                .trim();


            document
                .querySelectorAll('.activity-row')
                .forEach(function(row) {

                    const userName = row
                        .querySelector('.user-name')
                        .textContent
                        .toLowerCase();


                    row.style.display =
                        userName.includes(keyword)
                            ? ''
                            : 'none';

                });

        });

    }

</script>


{{-- ============================================================= --}}
{{-- SEARCH APPS USER --}}
{{-- ============================================================= --}}

<script>

    const searchAppUser = document.getElementById('searchAppUser');

    if (searchAppUser) {

        searchAppUser.addEventListener('keyup', function() {

            const keyword = this.value
                .toLowerCase()
                .trim();


            document
                .querySelectorAll('.app-activity-row')
                .forEach(function(row) {

                    const userName = row
                        .querySelector('.app-user-name')
                        .textContent
                        .toLowerCase();


                    row.style.display =
                        userName.includes(keyword)
                            ? ''
                            : 'none';

                });

        });

    }

</script>


<style>

    /*
    |--------------------------------------------------------------------------
    | METRIC ICON
    |--------------------------------------------------------------------------
    */

    .metric-icon {

        width: 52px;

        height: 52px;

        border-radius: 50%;

        display: flex;

        align-items: center;

        justify-content: center;

        flex-shrink: 0;

    }


    /*
    |--------------------------------------------------------------------------
    | STICKY TABLE
    |--------------------------------------------------------------------------
    */

    .it-table-wrapper {

        max-height: 650px;

        overflow-y: auto;

        overflow-x: auto;

    }


    .it-table-wrapper thead th {

        position: sticky;

        top: 0;

        z-index: 10;

        background: #f8f9fa;

        color: #6b7280;

        font-size: 0.75rem;

        font-weight: 600;

        text-transform: uppercase;

        letter-spacing: 0.05em;

        white-space: nowrap;

    }


    .it-table-wrapper td {

        white-space: nowrap;

    }


    /*
    |--------------------------------------------------------------------------
    | CARD
    |--------------------------------------------------------------------------
    */

    .card {

        transition:
            transform 0.2s ease,
            box-shadow 0.2s ease;

    }


    .card:hover {

        box-shadow:
            0 10px 25px -5px rgba(0, 0, 0, 0.05),
            0 8px 10px -6px rgba(0, 0, 0, 0.01) !important;

    }


    /*
    |--------------------------------------------------------------------------
    | CODE
    |--------------------------------------------------------------------------
    */

    code {

        color: #495057;

        background: #f8f9fa;

        padding: 2px 5px;

        border-radius: 4px;

        font-size: 12px;

    }


    /*
    |--------------------------------------------------------------------------
    | TAB
    |--------------------------------------------------------------------------
    */

    .nav-tabs .nav-link {

        color: #6c757d;

        border: none;

        padding: 12px 18px;

        font-weight: 600;

    }


    .nav-tabs .nav-link:hover {

        color: #0d6efd;

    }


    .nav-tabs .nav-link.active {

        color: #0d6efd;

        background: transparent;

        border-bottom: 2px solid #0d6efd;

    }

</style>

@endsection