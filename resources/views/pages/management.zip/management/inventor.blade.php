@extends('master.master')
@section('title','Inventor')
@section('content')
@include('pages.management.style')
<style>
    .modal-full-custom {
        max-width: 96%;
    }
    .inventor-row {
        cursor: pointer;
        transition: .2s;
    }
    .inventor-row:hover {
        background: #f5f5f5;
    }
    .qty-warning {
        font-size: 11px;
    }
</style>
<div class="container-fluid py-4">
    <div class="card inventor-card">
        <div class="card-header bg-white">
           <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

    {{-- LEFT --}}
    <h4 class="mb-0 fw-bold">
        INVENTORY SPK
    </h4>

    {{-- RIGHT --}}
    <div style="min-width:220px;">

        <select id="filterSpkType"
            class="form-control" >

            <option value="">
                Semua SPK
            </option>

            <option value="NW">
                SPK Produksi
            </option>

            <option value="NWS">
                SPK Sampel
            </option>

        </select>

    </div>

</div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table inventor-table table-bordered align-middle">
                    <thead>
                        <tr>
                            <th width="60">
                                No
                            </th>
                            <th>
                                No SPK
                            </th>
                            <th>
                                Supplier
                            </th>
                            <th>
                                Kategori
                            </th>
                            <th>
                                PO
                            </th>
                            <th>
                                Tgl Terima
                            </th>
                            <th>
                                Deadline
                            </th>
                            <th>
                                Status
                            </th>
                            <th width="120">
                                Total Item
                            </th>
                            <th width="120">
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($spks as $spk)
                        <tr>
                            <td>
                                {{ $loop->iteration }}
                            </td>
                            {{-- CLICK FOR INPUT --}}
                            <td class="inventor-row" data-id="{{ $spk['id'] }}">
                                <div class="fw-bold text-primary">
                                    {{ $spk['no_spk'] }}
                                </div>
                            </td>
                            <td class="inventor-row" data-id="{{ $spk['id'] }}">
                                {{ $spk['supplier'] }}
                            </td>
                            <td class="inventor-row" data-id="{{ $spk['id'] }}">
                                <span class="badge bg-info">
                                    {{ strtoupper($spk['kategori']) }}
                                </span>
                            </td>
                            <td class="inventor-row" data-id="{{ $spk['id'] }}">
                                {{ $spk['no_po'] }}
                            </td>
                            <td class="inventor-row" data-id="{{ $spk['id'] }}">
                                {{ $spk['tgl_terima'] }}
                            </td>
                            <td class="inventor-row" data-id="{{ $spk['id'] }}">
                                {{ $spk['tgl_selesai'] }}
                            </td>
                            <td class="inventor-row" data-id="{{ $spk['id'] }}">
                                @php
                                $statusColor = match($spk['status']) {
                                'closed' => 'success',
                                'progress' => 'warning',
                                default => 'secondary'
                                };
                                @endphp
                                <span class="badge bg-{{ $statusColor }}">
                                    {{ strtoupper($spk['status']) }}
                                </span>
                            </td>
                            <td class="text-center inventor-row" data-id="{{ $spk['id'] }}">
                                {{ count($spk['items']) }}
                            </td>
                            {{-- DETAIL BUTTON --}}
                            <td>
                                <button type="button" class="btn btn-primary btn-sm btn-detail"
                                    data-id="{{ $spk['id'] }}">
                                    Detail
                                </button>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="10" class="text-center text-muted py-5">
                                Tidak ada data SPK
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
{{-- ====================================================== --}}
{{-- MODAL INPUT INVENTORY --}}
{{-- ====================================================== --}}
<div class="modal fade" id="inventorModal" tabindex="-1">
    <div class="modal-dialog modal-full-custom modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            {{-- HEADER --}}
            <div class="modal-header bg-dark text-white">
                <h4 class="mb-0">
                    INPUT INVENTORY
                </h4>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal">
                </button>
            </div>
            {{-- BODY --}}
            <div class="modal-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="mb-0 fw-bold" id="modalSpkTitleText">
                        SPK #
                    </h5>
                    <button type="button" class="btn btn-primary" id="btnAddRow">
                        + Tambah
                    </button>
                </div>
                <form id="inventorForm">
                    @csrf
                    <input type="hidden" name="spk_id" id="modal_spk_id">
                    <div class="table-responsive">
                        <table class="table table-bordered align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th width="320">
                                        Item
                                    </th>
                                    <th width="140">
                                        Type
                                    </th>
                                    <th width="120">
                                        Qty
                                    </th>
                                    <th width="220">
                                        Supplier
                                    </th>
                                    <th width="160">
                                        Date
                                    </th>
                                    <th width="140">
                                        Time
                                    </th>
                                    <th>
                                        Remark
                                    </th>
                                    <th width="70">
                                        #
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="inventorTableBody">
                            </tbody>
                        </table>
                    </div>
                    <div class="text-end mt-4">
                        <button type="submit" class="btn btn-success">
                            Simpan Inventory
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
{{-- ====================================================== --}}
{{-- MODAL DETAIL --}}
{{-- ====================================================== --}}
<div class="modal fade" id="inventorDetailModal" tabindex="-1">
    <div class="modal-dialog modal-full-custom modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-dark text-white">
                <h4 class="mb-0">
                    DETAIL INVENTORY
                </h4>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    {{-- LEFT --}}
                    <div class="col-md-4">
                        <div class="card mb-3 border-0 shadow-sm">
                            <div class="card-header bg-primary text-white">
                                INFORMASI SPK
                            </div>
                            <div class="card-body" id="spkInfoArea">
                            </div>
                        </div>
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-secondary text-white">
                                LIST ITEM
                            </div>
                            <div class="card-body">
                                <div id="itemArea">
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- RIGHT --}}
                    <div class="col-md-8">
                        {{-- TIMELINE --}}
                        <div class="card mb-4 border-0 shadow-sm">
                            <div class="card-header bg-warning fw-bold">
                                INVENTORY TIMELINE
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Supplier</th>
                                                <th>Type</th>
                                                <th>Qty</th>
                                                <th>Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody id="timelineArea">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        {{-- PAYMENT --}}
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-success text-white fw-bold">
                                LIST PAYMENT
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Type</th>
                                                <th>Nilai</th>
                                                <th>
                                                    Saldo
                                                </th>
                                                <th>Keterangan</th>
                                            </tr>
                                        </thead>
                                        <tbody id="paymentArea">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('scripts')
<script>
    /*
    |--------------------------------------------------------------------------
    | OPEN INPUT MODAL
    |--------------------------------------------------------------------------
    */
    $(document).on('click', '.inventor-row', function () {
        let spkId = $(this).data('id');
        $('#modal_spk_id')
            .val(spkId);
        $.get(`/inventor/spk/${spkId}`, function (res) {
            window.currentItems =
                res.items;
            window.currentSupplier =
                res.supplier;
            $('#modalSpkTitleText')
                .html(
                    'SPK # ' +
                    (res.spk_no ?? '-')
                );
            $('#inventorTableBody')
                .html('');
            /*
            |--------------------------------------------------------------------------
            | EXISTING DATA
            |--------------------------------------------------------------------------
            */
            if (
                Array.isArray(res.timelines) &&
                res.timelines.length > 0
            ) {
                res.timelines.forEach(function (row) {
                    addInventorRow({
                        id: row.id,
                        detail_po_id: row.detail_po_id,
                        qty: row.qty,
                        type: row.type,
                        remark: row.remark,
                        date: row.date,
                        time: row.time,
                    });
                });
            } else {
                addInventorRow();
            }
            validateQty();
            $('#inventorModal')
                .modal('show');
        });
    });
    /*
    |--------------------------------------------------------------------------
    | ADD ROW
    |--------------------------------------------------------------------------
    */
    function addInventorRow(data = null) {
        let itemOptions = '';
        currentItems.forEach(item => {
            let selected = '';
            if (
                data &&
                data.detail_po_id == item.detail_po_id
            ) {
                selected = 'selected';
            }
            itemOptions += `
                 <option
                    value="${item.detail_po_id}"
                    data-maxqty="${item.qty}"
                    ${selected}>
                    ${item.nama} (${item.qty})
                </option>
            `;
        });
        let html = `
            <tr>
                {{-- ITEM --}}
                <td>
                    <select
                        name="detail_po_id[]"
                        class="form-control form-select">
                        ${itemOptions}
                    </select>
                </td>
                {{-- TYPE --}}
                <td>
                    <select
                        name="type[]"
                        class="form-control form-select">
                        <option
                            value="in"
                            ${data?.type == 'in' ? 'selected' : ''}>
                            IN
                        </option>
                        <option
                            value="kirim_rangka"
                            ${data?.type == 'kirim_rangka' ? 'selected' : ''}>
                            KIRIM RANGKA
                        </option>
                        <option
                            value="return"
                            ${data?.type == 'return' ? 'selected' : ''}>
                            RETURN
                        </option>
                    </select>
                </td>
                {{-- QTY --}}
                <td>
                    <input
                        type="number"
                        name="qty[]"
                        class="form-control qty-input"
                        value="${data?.qty ?? ''}">
                    <small class="text-danger qty-warning d-none">
                        Qty melebihi batas
                    </small>
                </td>
                {{-- SUPPLIER --}}
                <td>
                    <select
                        name="sup_id[]"
                        class="form-control form-select">
                        <option value="${currentSupplier.id}">
                            ${currentSupplier.name}
                        </option>
                    </select>
                </td>
                {{-- DATE --}}
                <td>
                    <input
                        type="date"
                        name="date[]"
                        class="form-control"
                        value="${data?.date ?? ''}">
                </td>
                {{-- TIME --}}
                <td>
                    <input
                        type="time"
                        name="time[]"
                        class="form-control"
                        value="${data?.time ?? ''}">
                </td>
                {{-- REMARK --}}
                <td>
                    <input
                        type="text"
                        name="remark[]"
                        class="form-control"
                        value="${data?.remark ?? ''}">
                </td>
                {{-- DELETE --}}
              <td class="text-center">
    <button
        type="button"
        class="btn btn-danger btn-sm btn-remove-row"
        data-id="${data?.id ?? ''}">
        ×
    </button>
</td>
            </tr>
        `;
        $('#inventorTableBody')
            .append(html);
    }
    /*
    |--------------------------------------------------------------------------
    | VALIDATE QTY
    |--------------------------------------------------------------------------
    */
    function validateQty() {
        let totals = {};
        $('#inventorTableBody tr').each(function () {
            let row = $(this);
            let itemId = row.find('select[name="detail_po_id[]"]').val();
            let qty = parseInt(
                row.find('.qty-input').val()
            ) || 0;
            if (!totals[itemId]) {
                totals[itemId] = 0;
            }
            totals[itemId] += qty;
        });
        let hasError = false;
        $('#inventorTableBody tr').each(function () {
            let row = $(this);
            let select = row.find('select[name="detail_po_id[]"]');
            let selectedOption =
                select.find('option:selected');
            let itemId =
                select.val();
            let maxQty =
                parseInt(
                    selectedOption.data('maxqty')
                ) || 0;
            let totalQty =
                totals[itemId] || 0;
            let input =
                row.find('.qty-input');
            let warning =
                row.find('.qty-warning');
            if (totalQty > maxQty) {
                hasError = true;
                input.addClass('is-invalid');
                warning
                    .removeClass('d-none')
                    .html(
                        `Total qty ${totalQty} melebihi batas ${maxQty}`
                    );
            } else {
                input.removeClass('is-invalid');
                warning.addClass('d-none');
            }
        });
        $('button[type="submit"]')
            .prop('disabled', hasError);
    }
    /*
    |--------------------------------------------------------------------------
    | VALIDATE EVENT
    |--------------------------------------------------------------------------
    */
    $(document).on(
        'keyup change',
        '.qty-input, select[name="detail_po_id[]"]',
        function () {
            validateQty();
        }
    );
    /*
    |--------------------------------------------------------------------------
    | ADD ROW BUTTON
    |--------------------------------------------------------------------------
    */
    $(document).on('click', '#btnAddRow', function () {
        addInventorRow();
    });
    /*
    |--------------------------------------------------------------------------
    | REMOVE ROW
    |--------------------------------------------------------------------------
    */
    $(document).on('click', '.btn-remove-row', function () {
        let btn = $(this);
        let row = btn.closest('tr');
        let timelineId = btn.data('id');
        // alert(timelineId);
        /*
        |--------------------------------------------------------------------------
        | DELETE DATABASE
        |--------------------------------------------------------------------------
        */
        if (timelineId) {
            Swal.fire({
                title: 'Hapus data?',
                text: 'Data inventory akan dihapus',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya Hapus'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: `/inventor/delete/${timelineId}`,
                        type: 'DELETE',
                        data: {
                            _token: $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (res) {
                            row.remove();
                            validateQty();
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil',
                                text: res.message
                            });
                        },
                        error: function () {
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops',
                                text: 'Gagal hapus data'
                            });
                        }
                    });
                }
            });
        } else {
            /*
            |--------------------------------------------------------------------------
            | DELETE ROW BARU (BELUM TERSIMPAN)
            |--------------------------------------------------------------------------
            */
            row.remove();
            validateQty();
        }
    });
    /*
    |--------------------------------------------------------------------------
    | SUBMIT
    |--------------------------------------------------------------------------
    */
    $('#inventorForm').submit(function (e) {
        e.preventDefault();
        $.ajax({
            url: "{{ route('inventor.store') }}",
            type: "POST",
            data: $(this).serialize(),
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function (res) {
                $('#inventorModal')
                    .modal('hide');
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: res.message
                });
            },
            error: function (xhr) {
                console.log(xhr);
                Swal.fire({
                    icon: 'error',
                    title: 'Oops',
                    text: 'Gagal simpan data'
                });
            }
        });
    });
    /*
    |--------------------------------------------------------------------------
    | DETAIL BUTTON
    |--------------------------------------------------------------------------
    */
    $(document).on('click', '.btn-detail', function (e) {
        e.stopPropagation();
        let spkId = $(this).data('id');
        $.get(`/inventor/spk/${spkId}`, function (res) {
            /*
            |--------------------------------------------------------------------------
            | INFO
            |--------------------------------------------------------------------------
            */
            let infoHtml = `
                <table class="table table-sm">
                    <tr>
                        <td width="120">No SPK</td>
                        <td>${res.spk_no}</td>
                    </tr>
                    <tr>
                        <td>Supplier</td>
                        <td>${res.supplier.name}</td>
                    </tr>
                    <tr>
                        <td>Kategori</td>
                        <td>${res.kategori}</td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td>${res.status}</td>
                    </tr>
                </table>
            `;
            $('#spkInfoArea')
                .html(infoHtml);
            /*
            |--------------------------------------------------------------------------
            | ITEMS
            |--------------------------------------------------------------------------
            */
            let itemHtml = '';
            res.items.forEach(item => {
                itemHtml += `
                    <div class="border rounded p-2 mb-2">
                        <div class="fw-bold">
                            ${item.nama}
                        </div>
                        <small>
                            ${item.kode ?? '-'}
                        </small>
                        <div>
                            Qty : ${item.qty}
                        </div>
                    </div>
                `;
            });
            $('#itemArea')
                .html(itemHtml);
            /*
            |--------------------------------------------------------------------------
            | TIMELINE
            |--------------------------------------------------------------------------
            */
            let timelineHtml = '';
            if (res.timelines.length > 0) {
                res.timelines.forEach((row, i) => {
                    timelineHtml += `
                        <tr>
                            <td>${i + 1}</td>
                            <td>${row.date}</td>
                            <td>${res.supplier.name}</td>
                            <td>${row.type}</td>
                            <td>${row.qty}</td>
                            <td>${row.remark ?? '-'}</td>
                        </tr>
                    `;
                });
            } else {
                timelineHtml = `
                    <tr>
                        <td colspan="6"
                            class="text-center text-muted py-4">
                            Tidak ada timeline
                        </td>
                    </tr>
                `;
            }
            $('#timelineArea')
                .html(timelineHtml);
          /*
|--------------------------------------------------------------------------
| PAYMENT
|--------------------------------------------------------------------------
*/

let paymentHtml = '';

let totalSpk = 0;

// =========================
// TOTAL SPK
// =========================

if (
    Array.isArray(res.items)
) {

    res.items.forEach(item => {

        totalSpk +=
            parseFloat(item.total || 0);

    });

}

let saldo = totalSpk;

// =========================
// BARIS TOTAL SPK
// =========================

paymentHtml += `

<tr class="table-primary">

    <td></td>

    <td></td>

    <td class="fw-bold">
        TOTAL SPK
    </td>

    <td class="fw-bold">

        Rp
        ${totalSpk.toLocaleString()}

    </td>

    <td class="fw-bold text-success">

        Rp
        ${saldo.toLocaleString()}

    </td>

    <td></td>

</tr>

`;

// =========================
// PAYMENT LIST
// =========================

if (
    Array.isArray(res.payments) &&
    res.payments.length > 0
) {

    res.payments.forEach((pay, i) => {

        let nilai =
            parseInt(pay.amount || 0);

        saldo -= nilai;

        paymentHtml += `

        <tr>

            <td>
                ${i + 1}
            </td>

            <td>
                ${pay.date ?? '-'}
            </td>

            <td>
                ${pay.note ?? '-'}
            </td>

            <td>

                Rp
                ${nilai.toLocaleString()}

            </td>

            <td class="
                fw-bold
                ${saldo <= 0
                    ? 'text-danger'
                    : 'text-success'}
            ">

                Rp
                ${saldo.toLocaleString()}

            </td>

            <td>
                ${pay.note_tambahan ?? '-'}
            </td>

        </tr>

        `;

    });

    // =====================
    // TOTAL PAYMENT
    // =====================

    let totalPayment = 0;

    res.payments.forEach(pay => {

        totalPayment +=
            parseInt(pay.amount || 0);

    });

    paymentHtml += `

    <tr class="table-success">

        <td colspan="3"
            class="text-end fw-bold">

            TOTAL PAYMENT

        </td>

        <td class="fw-bold">

            Rp
            ${totalPayment.toLocaleString()}

        </td>

        <td class="fw-bold">

            Rp
            ${saldo.toLocaleString()}

        </td>

        <td></td>

    </tr>

    `;

} else {

    paymentHtml += `

    <tr>

        <td colspan="6"
            class="text-center text-muted py-4">

            Tidak ada payment

        </td>

    </tr>

    `;
}

$('#paymentArea')
.html(paymentHtml);
            $('#inventorDetailModal')
                .modal('show');
        });
    });

    // NWS filter
   $(document).on('change', '#filterSpkType', function () {

    let value = $(this).val().trim().toUpperCase();

    $('table tbody tr').show();

    $('table tbody tr').each(function () {

        let text = $(this)
            .find('td:eq(1)')
            .text()
            .trim()
            .toUpperCase();

        // ambil bagian setelah /
        let parts = text.split('/');

        // contoh:
        // 26-0010/NWS 26 - 31/05/2026
        // hasil => NWS

        let prefix = '';

        if (parts.length > 1) {
            prefix = parts[1].trim().split(' ')[0];
        }

        // semua
        if (value === '') {
            $(this).show();
            return;
        }

        // filter
        if (prefix === value) {
            $(this).show();
        } else {
            $(this).hide();
        }

    });

});
</script>
@endpush
